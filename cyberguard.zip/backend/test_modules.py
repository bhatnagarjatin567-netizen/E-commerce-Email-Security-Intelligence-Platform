import os
import io
from app.core.database import SessionLocal
from app.models.user import User, UserRole
from app.services.ecommerce_service import execute_ecommerce_scan
from app.services.email_service import analyze_email_file
from app.services.smtp_service import run_plaintext_smtp_demo, run_spoofing_smtp_demo
from app.api.reports import _create_report_for_scan

def run_module_tests():
    db = SessionLocal()
    try:
        admin_user = db.query(User).filter(User.role == UserRole.ADMIN).first()
        assert admin_user is not None, "Admin user must exist in DB"
        print(f"Testing with user: {admin_user.email} (Role: {admin_user.role})")

        # 1. Test E-Commerce Scanner
        print("\n--- TEST 1: E-COMMERCE SECURITY ANALYSIS ---")
        # Test against http://example.com as an external HTTP target, or localhost
        target = "http://example.com"
        print(f"Running baseline assessment on target: {target}")
        scan1 = execute_ecommerce_scan(db, target, admin_user, confirm_active=False)
        print(f"E-commerce scan completed! Scan ID: {scan1.id}, Status: {scan1.status.value}, Findings Count: {scan1.findings_count}")
        for f in scan1.findings[:3]:
            print(f"  - [{f.severity.value}] {f.title} (CWE: {f.cwe_id})")

        # 2. Test Email Security Analyzer
        print("\n--- TEST 2: EMAIL (.EML) PARSER & PHISHING HEURISTICS ---")
        sample_eml = b"""From: "PayPal Account Security" <service@notification-paypal-alerts.top>
To: recipient@company.com
Reply-To: phisher-collector@harvest-box.xyz
Subject: URGENT: Your PayPal Account Has Been Suspended
Date: Sun, 22 Nov 2026 21:00:00 +0000
Message-ID: <12345.alert@paypal-alerts.top>
Content-Type: text/html; charset=UTF-8

<html>
<body>
<p>Dear customer, we detected an unauthorized login to your account. Action required immediately.</p>
<p>Click below to verify your password:</p>
<a href="http://192.168.1.50/login.php">https://www.paypal.com/signin/verify</a>
</body>
</html>
"""
        scan2 = analyze_email_file(db, sample_eml, "suspicious_paypal_lure.eml", admin_user)
        print(f"Email analysis completed! Scan ID: {scan2.id}, Status: {scan2.status.value}, Findings: {scan2.findings_count}")
        if scan2.email_analysis:
            print(f"  Sender: {scan2.email_analysis.sender}")
            print(f"  SPF: {scan2.email_analysis.spf_status}")
            print(f"  DKIM: {scan2.email_analysis.dkim_status}")
            print(f"  DMARC: {scan2.email_analysis.dmarc_status}")
            print(f"  Phishing Score: {scan2.email_analysis.phishing_score}/100")

        # 3. Test SMTP Security Laboratory
        print("\n--- TEST 3: SMTP SECURITY LABORATORY (LOCAL ISOLATED) ---")
        smtp_res = run_plaintext_smtp_demo(db, admin_user)
        print(f"Plaintext SMTP Demo finished! Status: {smtp_res['status']}, Transcript Lines: {len(smtp_res['transcript'])}")

        spoof_res = run_spoofing_smtp_demo(db, admin_user)
        print(f"Spoofing Demo finished! Status: {spoof_res['status']}, Spoofed Sender: {spoof_res['spoofed_sender']}")

        # 4. Test Report Generation from Scan
        print("\n--- TEST 4: SECURITY REPORT GENERATION ---")
        report = _create_report_for_scan(scan1.id, "Executive E-Commerce Assessment Report", None, admin_user, db)
        print(f"Report generated successfully! Report ID: {report.id}, Title: {report.title}")
        print(f"HTML Content Length: {len(report.html_content)} bytes")

        print("\n>>> ALL SESSION 2 & 3 BACKEND MODULE TESTS PASSED WITH 100% SUCCESS! <<<")

    finally:
        db.close()

if __name__ == "__main__":
    run_module_tests()
