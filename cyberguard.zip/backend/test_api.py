from fastapi.testclient import TestClient
from app.main import app

def run_tests():
    with TestClient(app) as client:
        print("1. Testing Health Endpoint...")
        res = client.get("/api/health")
        assert res.status_code == 200, f"Health check failed: {res.text}"
        print("Health check OK:", res.json())

        print("\n2. Testing Admin Login...")
        res = client.post("/api/v1/auth/login", json={
            "email": "admin@cyberguard.local",
            "password": "CyberGuard@Admin2026!"
        })
        assert res.status_code == 200, f"Admin login failed: {res.text}"
        admin_token = res.json()["access_token"]
        print("Admin login OK! Role:", res.json()["user"]["role"])

        print("\n3. Testing New User Registration (Pending Approval)...")
        # Use unique email if rerun
        import time
        email = f"alice_{int(time.time())}@cyberguard.local"
        res = client.post("/api/v1/auth/register", json={
            "full_name": "Alice Analyst",
            "email": email,
            "password": "Password123!",
            "confirm_password": "Password123!"
        })
        assert res.status_code == 201, f"Registration failed: {res.text}"
        data = res.json()
        alice_id = data["user_id"]
        print("Registration OK! Status:", data["status"], "User ID:", alice_id)

        print("\n4. Testing Login for Unapproved User (Should be blocked)...")
        res = client.post("/api/v1/auth/login", json={
            "email": email,
            "password": "Password123!"
        })
        assert res.status_code == 403, f"Expected 403, got: {res.status_code} {res.text}"
        print("Blocked as expected! Message:", res.json()["detail"])

        print("\n5. Testing Admin Approval Workflow...")
        res = client.post(
            f"/api/v1/admin/users/{alice_id}/approve",
            headers={"Authorization": f"Bearer {admin_token}"},
            json={
                "status": "APPROVED",
                "role": "ANALYST",
                "permissions": "scan:ecommerce,scan:email,lab:smtp,report:create,report:view"
            }
        )
        assert res.status_code == 200, f"Admin approval failed: {res.text}"
        print("User approved by Admin! Role:", res.json()["role"], "Status:", res.json()["status"])

        print("\n6. Testing Login for Approved User...")
        res = client.post("/api/v1/auth/login", json={
            "email": email,
            "password": "Password123!"
        })
        assert res.status_code == 200, f"Login failed for approved user: {res.text}"
        alice_token = res.json()["access_token"]
        print("Approved user logged in successfully! Token obtained.")

        print("\n7. Testing Protected Route /api/v1/auth/me...")
        res = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {alice_token}"})
        assert res.status_code == 200, f"Get profile failed: {res.text}"
        print("Profile validated:", res.json()["full_name"], "Role:", res.json()["role"])

        print("\n8. Testing Admin Stats Overview...")
        res = client.get("/api/v1/admin/stats", headers={"Authorization": f"Bearer {admin_token}"})
        assert res.status_code == 200, f"Admin stats failed: {res.text}"
        print("Admin stats total users:", res.json()["total_users"])

        print("\n9. Testing Dashboard Overview...")
        res = client.get("/api/v1/dashboard/overview", headers={"Authorization": f"Bearer {alice_token}"})
        assert res.status_code == 200, f"Dashboard overview failed: {res.text}"
        print("Dashboard stats:", res.json()["stats"])
        print("System status:", res.json()["system_status"])

        print("\n>>> ALL SESSION 1 BACKEND CORE TESTS PASSED SUCCESSFULLY! <<<")

if __name__ == "__main__":
    run_tests()
