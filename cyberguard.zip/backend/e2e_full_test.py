import json
import urllib.request
import urllib.parse
import subprocess
import time

def run_e2e_test():
    print("==================================================")
    print("      CYBERGUARD END-TO-END VERIFICATION")
    print("==================================================")

    # 1. Start server on 8008
    proc = subprocess.Popen(['python', '-m', 'uvicorn', 'app.main:app', '--host', '127.0.0.1', '--port', '8008'])
    time.sleep(2.5)

    try:
        # Step 1: Health check
        with urllib.request.urlopen('http://127.0.0.1:8008/api/health', timeout=3) as r:
            print("[1] Health check:", json.loads(r.read().decode()))

        # Step 2: Admin Login
        login_req = urllib.request.Request(
            'http://127.0.0.1:8008/api/v1/auth/login',
            data=json.dumps({'email': 'admin@cyberguard.io', 'password': 'CyberGuard@Admin2026!'}).encode(),
            headers={'Content-Type': 'application/json'}
        )
        with urllib.request.urlopen(login_req, timeout=3) as r:
            admin_data = json.loads(r.read().decode())
            token = admin_data['access_token']
            print("[2] Admin Login OK! Role:", admin_data['user']['role'])

        headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}

        # Step 3: Run E-Commerce Scan on http://example.com
        print("\n[3] Launching E-commerce Security Assessment...")
        scan_req = urllib.request.Request(
            'http://127.0.0.1:8008/api/v1/ecommerce/scan',
            data=json.dumps({'module': 'ECOMMERCE', 'target': 'http://example.com', 'scan_type': 'BASELINE'}).encode(),
            headers=headers
        )
        with urllib.request.urlopen(scan_req, timeout=8) as r:
            scan_res = json.loads(r.read().decode())
            scan_id = scan_res['id']
            print(f"    E-commerce Scan #{scan_id} Success! Status: {scan_res['status']}, Findings Count: {scan_res['findings_count']}")

        # Step 4: Run SMTP Laboratory Plaintext Demo
        print("\n[4] Running SMTP Plaintext Lab Demo...")
        smtp_req = urllib.request.Request(
            'http://127.0.0.1:8008/api/v1/smtp-lab/plaintext-demo',
            data=json.dumps({'sender': 'analyst@cyberguard.local', 'recipient': 'audit@test.local'}).encode(),
            headers=headers
        )
        with urllib.request.urlopen(smtp_req, timeout=5) as r:
            smtp_res = json.loads(r.read().decode())
            print(f"    SMTP Lab Plaintext Demo OK! Status: {smtp_res['status']}, Transcript Length: {len(smtp_res['transcript'])}")

        # Step 5: Run SMTP Laboratory Spoofing Demo
        print("\n[5] Running SMTP Sender Spoofing Lab Demo...")
        spoof_req = urllib.request.Request(
            'http://127.0.0.1:8008/api/v1/smtp-lab/spoof-demo',
            data=json.dumps({'spoofed_sender': 'ceo@megacorp.com', 'recipient': 'target@cyberguard.local'}).encode(),
            headers=headers
        )
        with urllib.request.urlopen(spoof_req, timeout=5) as r:
            spoof_res = json.loads(r.read().decode())
            print(f"    SMTP Lab Spoof Demo OK! Status: {spoof_res['status']}, Spoofed: {spoof_res['spoofed_sender']}")

        # Step 6: Generate Assessment Report
        print("\n[6] Generating Security Assessment Report...")
        rep_req = urllib.request.Request(
            f'http://127.0.0.1:8008/api/v1/reports/from-scan/{scan_id}',
            data=b'',
            headers=headers
        )
        with urllib.request.urlopen(rep_req, timeout=5) as r:
            rep_res = json.loads(r.read().decode())
            report_id = rep_res['id']
            print(f"    Report #{report_id} Created! Title: {rep_res['title']}")

        # Step 7: Export Report as HTML
        print("\n[7] Exporting Report as HTML Document...")
        html_req = urllib.request.Request(
            f'http://127.0.0.1:8008/api/v1/reports/{report_id}/export/html',
            headers={'Authorization': f'Bearer {token}'}
        )
        with urllib.request.urlopen(html_req, timeout=5) as r:
            html_content = r.read().decode()
            print(f"    Exported HTML Size: {len(html_content)} bytes (Contains <!DOCTYPE html>: {'<!DOCTYPE html>' in html_content})")

        # Step 8: Export Report as JSON
        print("\n[8] Exporting Report as JSON...")
        json_req = urllib.request.Request(
            f'http://127.0.0.1:8008/api/v1/reports/{report_id}/export/json',
            headers={'Authorization': f'Bearer {token}'}
        )
        with urllib.request.urlopen(json_req, timeout=5) as r:
            json_report = json.loads(r.read().decode())
            print(f"    Exported JSON Findings Count: {len(json_report['findings'])}")

        # Step 9: Verify Real Database Dashboard Stats
        print("\n[9] Verifying Internal Dashboard SQLite Aggregations...")
        dash_req = urllib.request.Request(
            'http://127.0.0.1:8008/api/v1/dashboard/overview',
            headers={'Authorization': f'Bearer {token}'}
        )
        with urllib.request.urlopen(dash_req, timeout=5) as r:
            dash_data = json.loads(r.read().decode())
            print("    Total Completed Scans:", dash_data['stats']['total_completed_scans'])
            print("    Total Confirmed Findings:", dash_data['stats']['total_findings'])
            print("    Severity Breakdown:", dash_data['stats']['severity_counts'])
            print("    Recent Scans Count:", len(dash_data['recent_scans']))
            print("    Recent Reports Count:", len(dash_data['recent_reports']))
            print("    System Status:", dash_data['system_status'])

        print("\n==================================================")
        print("   ALL FULL END-TO-END VERIFICATIONS PASSED 100%!")
        print("==================================================")

    finally:
        proc.terminate()
        proc.wait()
        print("Server process cleanly terminated.")

if __name__ == "__main__":
    run_e2e_test()
