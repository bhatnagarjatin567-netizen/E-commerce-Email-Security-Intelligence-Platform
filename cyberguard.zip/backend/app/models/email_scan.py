from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, DateTime, Text, Float, ForeignKey
from sqlalchemy.orm import relationship
from app.core.database import Base

class EmailAnalysisRecord(Base):
    __tablename__ = "email_analysis_records"

    id = Column(Integer, primary_key=True, index=True)
    scan_id = Column(Integer, ForeignKey("scan_records.id"), nullable=False, unique=True)
    
    sender = Column(String(255), nullable=True)
    recipient = Column(String(255), nullable=True)
    reply_to = Column(String(255), nullable=True)
    return_path = Column(String(255), nullable=True)
    subject = Column(String(512), nullable=True)
    message_id = Column(String(255), nullable=True)
    
    # Auth Checks
    spf_status = Column(String(50), default="NOT_CHECKED")  # PASS, FAIL, SOFTFAIL, NEUTRAL, NONE, ERROR
    spf_details = Column(Text, nullable=True)
    
    dkim_status = Column(String(50), default="NOT_CHECKED")  # PASS, FAIL, NONE, ERROR
    dkim_details = Column(Text, nullable=True)
    
    dmarc_status = Column(String(50), default="NOT_CHECKED")  # PASS, FAIL, NONE, ERROR
    dmarc_details = Column(Text, nullable=True)
    
    # Phishing & Threat Score
    phishing_score = Column(Float, default=0.0)  # 0.0 to 100.0
    phishing_indicators = Column(Text, nullable=True)  # JSON serialized list of detected indicators
    headers_json = Column(Text, nullable=True)
    received_chain_json = Column(Text, nullable=True)
    
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    scan = relationship("ScanRecord", back_populates="email_analysis")
