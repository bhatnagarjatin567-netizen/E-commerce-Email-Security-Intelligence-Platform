from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey
from sqlalchemy.orm import relationship
from app.core.database import Base

class SecurityReport(Base):
    __tablename__ = "security_reports"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    scan_id = Column(Integer, ForeignKey("scan_records.id"), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    module = Column(String(50), nullable=False)
    target = Column(String(512), nullable=False)
    
    executive_summary = Column(Text, nullable=True)
    findings_summary = Column(Text, nullable=True)  # JSON {critical: 1, high: 2, etc.}
    html_content = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    user = relationship("User", back_populates="reports")
    scan = relationship("ScanRecord", back_populates="reports")
