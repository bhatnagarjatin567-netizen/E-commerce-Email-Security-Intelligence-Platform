from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from app.core.database import Base

class AuthorizedTarget(Base):
    __tablename__ = "authorized_targets"

    id = Column(Integer, primary_key=True, index=True)
    url_or_domain = Column(String(512), unique=True, nullable=False)
    description = Column(String(255), nullable=True)
    added_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
