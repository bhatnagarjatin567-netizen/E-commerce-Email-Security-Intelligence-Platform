import enum
from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, DateTime, Text, Enum, ForeignKey, Float
from sqlalchemy.orm import relationship
from app.core.database import Base

class ScanModule(str, enum.Enum):
    ECOMMERCE = "ECOMMERCE"
    EMAIL = "EMAIL"
    SMTP_LAB = "SMTP_LAB"

class ScanStatus(str, enum.Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"

class FindingSeverity(str, enum.Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"

class ScanRecord(Base):
    __tablename__ = "scan_records"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    module = Column(Enum(ScanModule), nullable=False)
    target = Column(String(512), nullable=False)
    scan_type = Column(String(100), default="BASELINE")
    status = Column(Enum(ScanStatus), default=ScanStatus.PENDING, nullable=False)
    
    start_time = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completion_time = Column(DateTime, nullable=True)
    findings_count = Column(Integer, default=0)
    summary = Column(Text, nullable=True)
    raw_results = Column(Text, nullable=True)  # JSON formatted data

    user = relationship("User", back_populates="scans")
    findings = relationship("SecurityFinding", back_populates="scan", cascade="all, delete-orphan")
    email_analysis = relationship("EmailAnalysisRecord", back_populates="scan", uselist=False, cascade="all, delete-orphan")
    reports = relationship("SecurityReport", back_populates="scan")

class SecurityFinding(Base):
    __tablename__ = "security_findings"

    id = Column(Integer, primary_key=True, index=True)
    scan_id = Column(Integer, ForeignKey("scan_records.id"), nullable=False)
    title = Column(String(255), nullable=False)
    severity = Column(Enum(FindingSeverity), default=FindingSeverity.INFO, nullable=False)
    description = Column(Text, nullable=False)
    evidence = Column(Text, nullable=True)
    affected_component = Column(String(255), nullable=True)
    business_impact = Column(Text, nullable=True)
    remediation = Column(Text, nullable=True)
    cwe_id = Column(String(50), nullable=True)
    cvss_score = Column(Float, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    scan = relationship("ScanRecord", back_populates="findings")
