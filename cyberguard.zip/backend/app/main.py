import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core.database import engine, Base, SessionLocal
from app.models.user import User, AccountStatus, UserRole
from app.core.security import hash_password
from app.models.target import AuthorizedTarget
from app.api import auth, admin, dashboard, scans, reports, ecommerce, email_sec, smtp_lab

def init_db_and_admin():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        # Check if an admin user already exists
        admin_user = db.query(User).filter(User.role == UserRole.ADMIN).first()
        if not admin_user:
            admin_email = os.getenv("CYBERGUARD_ADMIN_EMAIL", "admin@cyberguard.io")
            admin_pass = os.getenv("CYBERGUARD_ADMIN_PASSWORD", "CyberGuard@Admin2026!")
            admin_user = User(
                email=admin_email,
                full_name="System Administrator",
                hashed_password=hash_password(admin_pass),
                status=AccountStatus.APPROVED,
                role=UserRole.ADMIN,
                permissions="admin:all,scan:ecommerce,scan:email,lab:smtp,report:create,report:view,user:manage,target:manage",
                is_active=True
            )
            db.add(admin_user)
            db.commit()
            print(f"[INIT] Created default initial administrator: {admin_email}")

        # Seed default authorized target (Juice Shop)
        default_target = db.query(AuthorizedTarget).filter(AuthorizedTarget.url_or_domain == "http://localhost:3000").first()
        if not default_target:
            db.add(AuthorizedTarget(
                url_or_domain="http://localhost:3000",
                description="Default Local OWASP Juice Shop Lab Target",
                is_active=True
            ))
            db.commit()
    except Exception as e:
        db.rollback()
        print(f"[INIT_ERROR] Error initializing database: {e}")
    finally:
        db.close()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    init_db_and_admin()
    yield
    # Shutdown

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Enterprise E-commerce & Email Security Intelligence Platform API",
    version="1.0.0",
    lifespan=lifespan
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows Vite dev server & proxy
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount API routers
app.include_router(auth.router, prefix=settings.API_V1_STR)
app.include_router(admin.router, prefix=settings.API_V1_STR)
app.include_router(dashboard.router, prefix=settings.API_V1_STR)
app.include_router(scans.router, prefix=settings.API_V1_STR)
app.include_router(reports.router, prefix=settings.API_V1_STR)
app.include_router(ecommerce.router, prefix=settings.API_V1_STR)
app.include_router(email_sec.router, prefix=settings.API_V1_STR)
app.include_router(smtp_lab.router, prefix=settings.API_V1_STR)

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "app": settings.PROJECT_NAME,
        "version": "1.0.0"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
