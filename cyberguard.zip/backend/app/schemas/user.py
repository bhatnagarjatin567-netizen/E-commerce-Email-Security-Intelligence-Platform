from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, field_validator
import re
from app.models.user import AccountStatus, UserRole

EMAIL_REGEX = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'

class UserBase(BaseModel):
    email: str
    full_name: str
    role: UserRole = UserRole.VIEWER
    status: AccountStatus = AccountStatus.PENDING_APPROVAL
    permissions: str = "report:view"

    @field_validator('email')
    @classmethod
    def validate_email(cls, v: str) -> str:
        clean = v.strip().lower()
        if not re.match(EMAIL_REGEX, clean):
            raise ValueError('Invalid email format')
        return clean

class UserCreate(UserBase):
    password: str

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    role: Optional[UserRole] = None
    status: Optional[AccountStatus] = None
    permissions: Optional[str] = None
    is_active: Optional[bool] = None

class UserResponse(BaseModel):
    id: int
    email: str
    full_name: str
    role: UserRole
    status: AccountStatus
    permissions: str
    is_active: bool
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class AdminUserApproval(BaseModel):
    status: AccountStatus  # APPROVED or REJECTED
    role: Optional[UserRole] = UserRole.ANALYST
    permissions: Optional[str] = "scan:ecommerce,scan:email,lab:smtp,report:create,report:view"
