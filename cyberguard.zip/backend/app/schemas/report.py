from datetime import datetime
from typing import Optional, Dict, Any
from pydantic import BaseModel

class ReportCreate(BaseModel):
    scan_id: int
    title: Optional[str] = None
    executive_summary: Optional[str] = None

class ReportResponse(BaseModel):
    id: int
    title: str
    scan_id: Optional[int]
    user_id: int
    module: str
    target: str
    executive_summary: Optional[str]
    findings_summary: Optional[str]
    html_content: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True

class AuditLogResponse(BaseModel):
    id: int
    user_id: Optional[int]
    action: str
    target_resource: Optional[str]
    details: Optional[str]
    ip_address: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True
