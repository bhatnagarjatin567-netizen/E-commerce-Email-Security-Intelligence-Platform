from datetime import datetime
from typing import Optional, List, Any
from pydantic import BaseModel, HttpUrl
from app.models.scan import ScanModule, ScanStatus, FindingSeverity

class SecurityFindingBase(BaseModel):
    title: str
    severity: FindingSeverity
    description: str
    evidence: Optional[str] = None
    affected_component: Optional[str] = None
    business_impact: Optional[str] = None
    remediation: Optional[str] = None
    cwe_id: Optional[str] = None
    cvss_score: Optional[float] = None

class SecurityFindingCreate(SecurityFindingBase):
    pass

class SecurityFindingResponse(SecurityFindingBase):
    id: int
    scan_id: int
    created_at: datetime

    class Config:
        from_attributes = True

class ScanCreateRequest(BaseModel):
    module: ScanModule
    target: str
    scan_type: Optional[str] = "BASELINE"
    confirm_active_scan: Optional[bool] = False

class ManualEvidenceCreate(BaseModel):
    scan_id: int
    title: str
    severity: FindingSeverity
    description: str
    evidence: str
    affected_component: Optional[str] = "Browser Storage / Token"
    business_impact: Optional[str] = None
    remediation: Optional[str] = None

class ScanResponse(BaseModel):
    id: int
    user_id: int
    module: ScanModule
    target: str
    scan_type: str
    status: ScanStatus
    start_time: datetime
    completion_time: Optional[datetime] = None
    findings_count: int
    summary: Optional[str] = None
    findings: List[SecurityFindingResponse] = []

    class Config:
        from_attributes = True
