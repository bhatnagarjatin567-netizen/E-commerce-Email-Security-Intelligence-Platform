from typing import Dict, Any, Optional
from pydantic import BaseModel
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.dependencies import require_analyst_or_admin, check_permission
from app.models.user import User
from app.services.smtp_service import (
    get_lab_server_status,
    ensure_lab_server_running,
    run_plaintext_smtp_demo,
    run_starttls_smtp_demo,
    run_spoofing_smtp_demo
)

router = APIRouter(prefix="/smtp-lab", tags=["SMTP Security Lab"])

class PlaintextDemoRequest(BaseModel):
    sender: Optional[str] = "analyst@cyberguard.local"
    recipient: Optional[str] = "target@cyberguard.local"
    subject: Optional[str] = "Security Assessment Wire Transmission"
    body: Optional[str] = "CYBERGUARD Lab Test: Cleartext protocol demonstration."

class StarttlsDemoRequest(BaseModel):
    host: Optional[str] = "127.0.0.1"
    port: Optional[int] = 10225

class SpoofDemoRequest(BaseModel):
    spoofed_sender: Optional[str] = "executive@trusted-enterprise.com"
    recipient: Optional[str] = "victim@cyberguard.local"
    subject: Optional[str] = "URGENT: Executive Wire Transfer Authorization"
    body: Optional[str] = "Please remit the attached invoice funds to vendor account #88921 immediately."

@router.get("/status")
def get_status(
    current_user: User = Depends(require_analyst_or_admin)
):
    ensure_lab_server_running()
    return get_lab_server_status()

@router.post("/plaintext-demo")
def execute_plaintext_demo(
    data: PlaintextDemoRequest,
    current_user: User = Depends(check_permission("lab:smtp")),
    db: Session = Depends(get_db)
):
    try:
        res = run_plaintext_smtp_demo(
            db=db,
            user=current_user,
            sender=data.sender,
            recipient=data.recipient,
            subject=data.subject,
            body=data.body
        )
        return res
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Plaintext demo error: {str(e)}")

@router.post("/starttls-demo")
def execute_starttls_demo(
    data: StarttlsDemoRequest,
    current_user: User = Depends(check_permission("lab:smtp")),
    db: Session = Depends(get_db)
):
    # Enforce localhost only for lab tests
    if data.host not in ["127.0.0.1", "localhost"]:
        raise HTTPException(status_code=400, detail="Lab experiments are strictly confined to 127.0.0.1 or localhost.")
    
    try:
        res = run_starttls_smtp_demo(
            db=db,
            user=current_user,
            target_host=data.host,
            target_port=data.port or 10225
        )
        return res
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"STARTTLS demo error: {str(e)}")

@router.post("/spoof-demo")
def execute_spoof_demo(
    data: SpoofDemoRequest,
    current_user: User = Depends(check_permission("lab:smtp")),
    db: Session = Depends(get_db)
):
    try:
        res = run_spoofing_smtp_demo(
            db=db,
            user=current_user,
            spoofed_sender=data.spoofed_sender,
            recipient=data.recipient,
            subject=data.subject,
            body=data.body
        )
        return res
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Spoofing demo error: {str(e)}")
