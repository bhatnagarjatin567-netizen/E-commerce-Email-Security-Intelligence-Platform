from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Request, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.core.database import get_db
from app.core.dependencies import require_admin
from app.models.user import User, AccountStatus, UserRole
from app.models.scan import ScanRecord
from app.models.audit import AuditLog
from app.models.target import AuthorizedTarget
from app.schemas.user import UserResponse, AdminUserApproval
from app.schemas.audit import AuditLogResponse
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/admin", tags=["Admin Management"], dependencies=[Depends(require_admin)])

@router.get("/stats")
def get_admin_dashboard_stats(db: Session = Depends(get_db)):
    total_users = db.query(User).count()
    pending_users = db.query(User).filter(User.status == AccountStatus.PENDING_APPROVAL).count()
    approved_users = db.query(User).filter(User.status == AccountStatus.APPROVED).count()
    disabled_users = db.query(User).filter(User.status == AccountStatus.DISABLED).count()
    rejected_users = db.query(User).filter(User.status == AccountStatus.REJECTED).count()
    total_scans = db.query(ScanRecord).count()
    
    # Recent audits
    recent_audits = (
        db.query(AuditLog)
        .order_by(AuditLog.created_at.desc())
        .limit(10)
        .all()
    )

    return {
        "total_users": total_users,
        "pending_users": pending_users,
        "approved_users": approved_users,
        "disabled_users": disabled_users,
        "rejected_users": rejected_users,
        "total_scans": total_scans,
        "recent_activity": [
            {
                "id": a.id,
                "action": a.action,
                "target": a.target_resource,
                "details": a.details,
                "created_at": a.created_at
            }
            for a in recent_audits
        ]
    }

@router.get("/users", response_model=List[UserResponse])
def list_users(
    status_filter: Optional[AccountStatus] = None,
    role_filter: Optional[UserRole] = None,
    db: Session = Depends(get_db)
):
    query = db.query(User)
    if status_filter:
        query = query.filter(User.status == status_filter)
    if role_filter:
        query = query.filter(User.role == role_filter)
    return query.order_by(User.created_at.desc()).all()

@router.post("/users/{user_id}/approve", response_model=UserResponse)
def approve_user(
    user_id: int,
    approval_data: AdminUserApproval,
    request: Request,
    current_admin: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.status = AccountStatus.APPROVED
    if approval_data.role:
        user.role = approval_data.role
    if approval_data.permissions:
        user.permissions = approval_data.permissions
    user.is_active = True

    db.commit()
    db.refresh(user)

    client_ip = request.client.host if request.client else "unknown"
    log_audit_event(
        db=db,
        action="ADMIN_APPROVE_USER",
        user_id=current_admin.id,
        target_resource=user.email,
        details=f"Admin {current_admin.email} approved user {user.email} with role {user.role.value}",
        ip_address=client_ip
    )

    return user

@router.post("/users/{user_id}/reject", response_model=UserResponse)
def reject_user(
    user_id: int,
    request: Request,
    current_admin: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if user.id == current_admin.id:
        raise HTTPException(status_code=400, detail="Cannot reject your own admin account")

    user.status = AccountStatus.REJECTED
    user.is_active = False
    db.commit()
    db.refresh(user)

    client_ip = request.client.host if request.client else "unknown"
    log_audit_event(
        db=db,
        action="ADMIN_REJECT_USER",
        user_id=current_admin.id,
        target_resource=user.email,
        details=f"Admin {current_admin.email} rejected user {user.email}",
        ip_address=client_ip
    )

    return user

@router.post("/users/{user_id}/toggle-status", response_model=UserResponse)
def toggle_user_status(
    user_id: int,
    request: Request,
    current_admin: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    if user.id == current_admin.id:
        raise HTTPException(status_code=400, detail="Cannot disable your own admin account")

    if user.status == AccountStatus.DISABLED:
        user.status = AccountStatus.APPROVED
        user.is_active = True
        action_name = "ADMIN_ENABLE_USER"
        detail_msg = f"Admin {current_admin.email} reactivated user {user.email}"
    else:
        user.status = AccountStatus.DISABLED
        user.is_active = False
        action_name = "ADMIN_DISABLE_USER"
        detail_msg = f"Admin {current_admin.email} disabled user {user.email}"

    db.commit()
    db.refresh(user)

    client_ip = request.client.host if request.client else "unknown"
    log_audit_event(
        db=db,
        action=action_name,
        user_id=current_admin.id,
        target_resource=user.email,
        details=detail_msg,
        ip_address=client_ip
    )

    return user

@router.put("/users/{user_id}/role", response_model=UserResponse)
def update_user_role_and_permissions(
    user_id: int,
    role: UserRole = Query(...),
    permissions: str = Query(...),
    request: Request = None,
    current_admin: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.role = role
    user.permissions = permissions
    db.commit()
    db.refresh(user)

    client_ip = request.client.host if request and request.client else "unknown"
    log_audit_event(
        db=db,
        action="ADMIN_UPDATE_ROLE",
        user_id=current_admin.id,
        target_resource=user.email,
        details=f"Admin updated role to {role.value} and permissions to {permissions}",
        ip_address=client_ip
    )

    return user

@router.get("/audit-logs", response_model=List[AuditLogResponse])
def get_audit_logs(
    limit: int = 50,
    offset: int = 0,
    db: Session = Depends(get_db)
):
    return (
        db.query(AuditLog)
        .order_by(AuditLog.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )

@router.get("/targets")
def list_authorized_targets(db: Session = Depends(get_db)):
    return db.query(AuthorizedTarget).all()

@router.post("/targets")
def add_authorized_target(
    url_or_domain: str = Query(...),
    description: str = Query(None),
    current_admin: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    existing = db.query(AuthorizedTarget).filter(AuthorizedTarget.url_or_domain == url_or_domain).first()
    if existing:
        raise HTTPException(status_code=400, detail="Target already exists in authorization list")
    
    target = AuthorizedTarget(
        url_or_domain=url_or_domain.strip(),
        description=description,
        added_by_user_id=current_admin.id,
        is_active=True
    )
    db.add(target)
    db.commit()
    db.refresh(target)
    return target

@router.delete("/targets/{target_id}")
def delete_authorized_target(
    target_id: int,
    db: Session = Depends(get_db)
):
    target = db.query(AuthorizedTarget).filter(AuthorizedTarget.id == target_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="Target not found")
    db.delete(target)
    db.commit()
    return {"message": "Target deleted successfully"}
