import json
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.dependencies import require_analyst_or_admin, check_permission
from app.models.user import User
from app.models.scan import ScanRecord, ScanModule
from app.models.email_scan import EmailAnalysisRecord
from app.schemas.scan import ScanResponse
from app.services.email_service import analyze_email_file

router = APIRouter(prefix="/email", tags=["Email Security"])

@router.get("/status")
def get_email_sec_status(
    current_user: User = Depends(require_analyst_or_admin)
):
    return {
        "status": "ready",
        "description": "Email .eml upload, SPF, DKIM, DMARC and Phishing Heuristics Analyzer"
    }

@router.post("/analyze")
async def upload_and_analyze_email(
    file: UploadFile = File(...),
    current_user: User = Depends(check_permission("scan:email")),
    db: Session = Depends(get_db)
):
    if not file.filename.lower().endswith(('.eml', '.msg', '.txt')):
        raise HTTPException(
            status_code=400,
            detail="Invalid file format. Please upload an RFC822 format email (.eml) file."
        )

    # Read content
    contents = await file.read()
    if len(contents) == 0:
        raise HTTPException(status_code=400, detail="The uploaded file is empty.")

    if len(contents) > 10 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="File exceeds maximum allowed size of 10MB.")

    try:
        scan_record = analyze_email_file(
            db=db,
            raw_content=contents,
            filename=file.filename,
            user=current_user
        )
        
        email_analysis = db.query(EmailAnalysisRecord).filter(EmailAnalysisRecord.scan_id == scan_record.id).first()
        
        return {
            "scan_id": scan_record.id,
            "filename": file.filename,
            "status": scan_record.status.value,
            "findings_count": scan_record.findings_count,
            "summary": scan_record.summary,
            "email_analysis": {
                "sender": email_analysis.sender if email_analysis else None,
                "recipient": email_analysis.recipient if email_analysis else None,
                "subject": email_analysis.subject if email_analysis else None,
                "reply_to": email_analysis.reply_to if email_analysis else None,
                "return_path": email_analysis.return_path if email_analysis else None,
                "spf_status": email_analysis.spf_status if email_analysis else None,
                "spf_details": email_analysis.spf_details if email_analysis else None,
                "dkim_status": email_analysis.dkim_status if email_analysis else None,
                "dkim_details": email_analysis.dkim_details if email_analysis else None,
                "dmarc_status": email_analysis.dmarc_status if email_analysis else None,
                "dmarc_details": email_analysis.dmarc_details if email_analysis else None,
                "phishing_score": email_analysis.phishing_score if email_analysis else 0.0,
                "phishing_indicators": json.loads(email_analysis.phishing_indicators) if email_analysis and email_analysis.phishing_indicators else [],
                "headers": json.loads(email_analysis.headers_json) if email_analysis and email_analysis.headers_json else {},
                "received_chain": json.loads(email_analysis.received_chain_json) if email_analysis and email_analysis.received_chain_json else []
            },
            "findings": [
                {
                    "id": f.id,
                    "title": f.title,
                    "severity": f.severity.value,
                    "description": f.description,
                    "evidence": f.evidence,
                    "remediation": f.remediation
                }
                for f in scan_record.findings
            ]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to analyze email: {str(e)}")

@router.get("/history", response_model=List[ScanResponse])
def get_email_history(
    current_user: User = Depends(require_analyst_or_admin),
    db: Session = Depends(get_db)
):
    return (
        db.query(ScanRecord)
        .filter(ScanRecord.module == ScanModule.EMAIL)
        .order_by(ScanRecord.start_time.desc())
        .all()
    )
