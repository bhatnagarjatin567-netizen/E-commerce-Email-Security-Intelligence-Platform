import shutil
import socket
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.core.database import get_db
from app.core.dependencies import get_current_user
from app.models.user import User
from app.models.scan import ScanRecord, SecurityFinding, FindingSeverity, ScanStatus
from app.models.report import SecurityReport
from app.core.config import settings

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

@router.get("/overview")
def get_dashboard_overview(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Total completed scans
    total_completed_scans = db.query(ScanRecord).filter(ScanRecord.status == ScanStatus.COMPLETED).count()
    total_scans = db.query(ScanRecord).count()
    
    # Total findings
    total_findings = db.query(SecurityFinding).count()

    # Severity distribution
    severity_counts = {
        "CRITICAL": db.query(SecurityFinding).filter(SecurityFinding.severity == FindingSeverity.CRITICAL).count(),
        "HIGH": db.query(SecurityFinding).filter(SecurityFinding.severity == FindingSeverity.HIGH).count(),
        "MEDIUM": db.query(SecurityFinding).filter(SecurityFinding.severity == FindingSeverity.MEDIUM).count(),
        "LOW": db.query(SecurityFinding).filter(SecurityFinding.severity == FindingSeverity.LOW).count(),
        "INFO": db.query(SecurityFinding).filter(SecurityFinding.severity == FindingSeverity.INFO).count(),
    }

    # Module breakdown
    module_counts = dict(
        db.query(ScanRecord.module, func.count(ScanRecord.id))
        .group_by(ScanRecord.module)
        .all()
    )

    # Recent scans (limit 5)
    recent_scans = (
        db.query(ScanRecord)
        .order_by(ScanRecord.start_time.desc())
        .limit(5)
        .all()
    )

    # Recent reports (limit 5)
    recent_reports = (
        db.query(SecurityReport)
        .order_by(SecurityReport.created_at.desc())
        .limit(5)
        .all()
    )

    # Check real system tool status
    openssl_detected = shutil.which("openssl") is not None
    # Check if zap port is reachable
    zap_reachable = False
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.2)
        result = s.connect_ex(("127.0.0.1", 8080))
        zap_reachable = (result == 0)
        s.close()
    except Exception:
        zap_reachable = False

    return {
        "stats": {
            "total_completed_scans": total_completed_scans,
            "total_scans": total_scans,
            "total_findings": total_findings,
            "severity_counts": severity_counts,
            "module_counts": {str(k.value if hasattr(k, "value") else k): v for k, v in module_counts.items()}
        },
        "recent_scans": [
            {
                "id": s.id,
                "module": s.module.value if hasattr(s.module, "value") else s.module,
                "target": s.target,
                "status": s.status.value if hasattr(s.status, "value") else s.status,
                "findings_count": s.findings_count,
                "start_time": s.start_time,
                "completion_time": s.completion_time
            }
            for s in recent_scans
        ],
        "recent_reports": [
            {
                "id": r.id,
                "title": r.title,
                "module": r.module,
                "target": r.target,
                "created_at": r.created_at
            }
            for r in recent_reports
        ],
        "system_status": {
            "database": "Online (SQLite)",
            "openssl_installed": openssl_detected,
            "zap_daemon": "Connected (8080)" if zap_reachable else "Offline / Standby (Native Fallbacks Active)",
            "dns_resolver": "Ready (dnspython)",
            "smtp_engine": "Ready (aiosmtpd)"
        }
    }
