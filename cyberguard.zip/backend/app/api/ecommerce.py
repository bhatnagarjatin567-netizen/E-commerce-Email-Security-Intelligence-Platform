from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.dependencies import require_analyst_or_admin, check_permission
from app.models.user import User
from app.models.scan import ScanRecord, ScanModule
from app.schemas.scan import ScanResponse, ScanCreateRequest
from app.services.ecommerce_service import execute_ecommerce_scan

router = APIRouter(prefix="/ecommerce", tags=["E-commerce Security"])

@router.get("/status")
def get_ecommerce_status(
    current_user: User = Depends(require_analyst_or_admin)
):
    return {
        "status": "ready",
        "default_target": "http://localhost:3000",
        "description": "OWASP Juice Shop & E-commerce security analysis module"
    }

@router.post("/scan", response_model=ScanResponse)
def launch_ecommerce_scan(
    request: ScanCreateRequest,
    current_user: User = Depends(check_permission("scan:ecommerce")),
    db: Session = Depends(get_db)
):
    if not request.target:
        raise HTTPException(status_code=400, detail="Target URL is required.")

    # Require explicit confirmation for active scanning
    if request.scan_type == "ACTIVE" and not request.confirm_active_scan:
        raise HTTPException(
            status_code=400,
            detail="Active scanning requires explicit confirmation of authorization."
        )

    try:
        scan_record = execute_ecommerce_scan(
            db=db,
            target_url=request.target.strip(),
            user=current_user,
            confirm_active=bool(request.confirm_active_scan)
        )
        return scan_record
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Scan execution error: {str(e)}")

@router.get("/history", response_model=List[ScanResponse])
def get_ecommerce_history(
    current_user: User = Depends(require_analyst_or_admin),
    db: Session = Depends(get_db)
):
    return (
        db.query(ScanRecord)
        .filter(ScanRecord.module == ScanModule.ECOMMERCE)
        .order_by(ScanRecord.start_time.desc())
        .all()
    )
