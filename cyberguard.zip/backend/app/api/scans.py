from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.dependencies import get_current_user, require_admin
from app.models.user import User, UserRole
from app.models.scan import ScanRecord, SecurityFinding, ScanModule, ScanStatus
from app.schemas.scan import ScanResponse, SecurityFindingResponse, ManualEvidenceCreate
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/scans", tags=["Scans"])

@router.get("/", response_model=List[ScanResponse])
def get_scan_history(
    module: Optional[ScanModule] = None,
    status_filter: Optional[ScanStatus] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(ScanRecord)
    
    # If viewer or analyst, view permissions apply:
    if current_user.role == UserRole.VIEWER:
        # viewers see all completed scans or scans assigned to them
        pass

    if module:
        query = query.filter(ScanRecord.module == module)
    if status_filter:
        query = query.filter(ScanRecord.status == status_filter)

    return query.order_by(ScanRecord.start_time.desc()).all()

@router.get("/{scan_id}", response_model=ScanResponse)
def get_scan_details(
    scan_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    scan = db.query(ScanRecord).filter(ScanRecord.id == scan_id).first()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan record not found")
    return scan

@router.post("/manual-evidence", response_model=SecurityFindingResponse)
def add_manual_evidence(
    data: ManualEvidenceCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Only analysts and admins can add manual observations
    if current_user.role not in [UserRole.ADMIN, UserRole.ANALYST]:
        raise HTTPException(status_code=403, detail="Permission denied to add security findings")

    scan = db.query(ScanRecord).filter(ScanRecord.id == data.scan_id).first()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")

    finding = SecurityFinding(
        scan_id=scan.id,
        title=data.title,
        severity=data.severity,
        description=data.description,
        evidence=data.evidence,
        affected_component=data.affected_component,
        business_impact=data.business_impact,
        remediation=data.remediation
    )
    db.add(finding)
    
    # Update scan findings count
    scan.findings_count = (scan.findings_count or 0) + 1
    db.commit()
    db.refresh(finding)

    log_audit_event(
        db=db,
        action="MANUAL_EVIDENCE_ADDED",
        user_id=current_user.id,
        target_resource=scan.target,
        details=f"Added finding '{finding.title}' with severity {finding.severity.value}"
    )

    return finding

@router.delete("/{scan_id}")
def delete_scan(
    scan_id: int,
    current_user: User = Depends(require_admin),
    db: Session = Depends(get_db)
):
    scan = db.query(ScanRecord).filter(ScanRecord.id == scan_id).first()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan record not found")
    
    db.delete(scan)
    db.commit()
    return {"message": "Scan record deleted successfully"}
