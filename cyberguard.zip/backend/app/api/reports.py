import json
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Response
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.dependencies import get_current_user
from app.models.user import User, UserRole
from app.models.report import SecurityReport
from app.models.scan import ScanRecord, SecurityFinding
from app.schemas.report import ReportResponse, ReportCreate
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/reports", tags=["Reports"])

@router.get("/", response_model=List[ReportResponse])
def list_reports(
    module: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(SecurityReport)
    if module:
        query = query.filter(SecurityReport.module == module)
    return query.order_by(SecurityReport.created_at.desc()).all()

@router.get("/{report_id}", response_model=ReportResponse)
def get_report(
    report_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    report = db.query(SecurityReport).filter(SecurityReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return report

@router.post("/", response_model=ReportResponse)
def generate_report(
    data: ReportCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return _create_report_for_scan(data.scan_id, data.title, data.executive_summary, current_user, db)

@router.post("/from-scan/{scan_id}", response_model=ReportResponse)
def generate_report_from_scan(
    scan_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return _create_report_for_scan(scan_id, None, None, current_user, db)

def _create_report_for_scan(
    scan_id: int,
    title: Optional[str],
    executive_summary: Optional[str],
    current_user: User,
    db: Session
):
    if current_user.role == UserRole.VIEWER and "report:create" not in (current_user.permissions or ""):
        raise HTTPException(status_code=403, detail="Viewer role is not authorized to generate new reports")

    scan = db.query(ScanRecord).filter(ScanRecord.id == scan_id).first()
    if not scan:
        raise HTTPException(status_code=404, detail="Scan record not found")

    findings = db.query(SecurityFinding).filter(SecurityFinding.scan_id == scan.id).all()
    
    # Calculate severity counts
    sev_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
    for f in findings:
        sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
        sev_counts[sev] = sev_counts.get(sev, 0) + 1

    report_title = title or f"Security Assessment Report: {scan.target} ({scan.module.value})"
    exec_summary = executive_summary or (
        f"CYBERGUARD security assessment conducted on target '{scan.target}' using module {scan.module.value}. "
        f"A total of {len(findings)} findings were identified during the assessment "
        f"({sev_counts['CRITICAL']} Critical, {sev_counts['HIGH']} High, {sev_counts['MEDIUM']} Medium, {sev_counts['LOW']} Low, {sev_counts['INFO']} Informational)."
    )

    # Render HTML template for the report
    html_findings = ""
    for idx, f in enumerate(findings, 1):
        sev_color = {
            "CRITICAL": "#b91c1c",
            "HIGH": "#c2410c",
            "MEDIUM": "#b45309",
            "LOW": "#15803d",
            "INFO": "#0369a1"
        }.get(f.severity.value, "#334155")

        html_findings += f"""
        <div style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-bottom: 16px; background-color: #ffffff;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                <h3 style="margin: 0; font-size: 16px; color: #0f172a;">{idx}. {f.title}</h3>
                <span style="background-color: {sev_color}; color: #ffffff; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">{f.severity.value}</span>
            </div>
            <p style="color: #475569; font-size: 14px; margin: 4px 0;"><strong>Component:</strong> {f.affected_component or 'N/A'}</p>
            <p style="color: #475569; font-size: 14px; margin: 4px 0;"><strong>Description:</strong> {f.description}</p>
            {f'<div style="background-color: #f8fafc; border: 1px solid #e2e8f0; padding: 8px; border-radius: 4px; font-family: monospace; font-size: 12px; margin: 8px 0; overflow-x: auto;"><strong>Evidence:</strong><br>{f.evidence}</div>' if f.evidence else ''}
            <p style="color: #475569; font-size: 14px; margin: 4px 0;"><strong>Business Impact:</strong> {f.business_impact or 'N/A'}</p>
            <p style="color: #0369a1; font-size: 14px; margin: 4px 0;"><strong>Remediation:</strong> {f.remediation or 'N/A'}</p>
        </div>
        """

    html_doc = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{report_title}</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; line-height: 1.5; color: #0f172a; margin: 0; padding: 40px; background-color: #f8fafc; }}
        .container {{ max-width: 900px; margin: 0 auto; background: #ffffff; padding: 40px; border-radius: 10px; border: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }}
        .header {{ border-bottom: 2px solid #0284c7; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }}
        .brand {{ font-size: 22px; font-weight: 800; color: #0f172a; letter-spacing: -0.5px; }}
        .badge {{ background-color: #f1f5f9; color: #475569; padding: 4px 10px; border-radius: 6px; font-size: 12px; }}
        .meta-grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 30px; background-color: #f8fafc; padding: 16px; border-radius: 8px; border: 1px solid #e2e8f0; }}
        .meta-item label {{ font-size: 12px; color: #64748b; text-transform: uppercase; font-weight: 600; display: block; }}
        .meta-item span {{ font-size: 14px; font-weight: 600; color: #1e293b; }}
        .summary-box {{ background-color: #f0fdf4; border-left: 4px solid #16a34a; padding: 16px; margin-bottom: 30px; border-radius: 0 8px 8px 0; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div>
                <div class="brand">CYBERGUARD</div>
                <div style="font-size: 13px; color: #64748b;">Enterprise Security Intelligence Platform</div>
            </div>
            <div class="badge">Official Security Assessment</div>
        </div>
        <h1 style="font-size: 24px; margin-top: 0;">{report_title}</h1>
        <div class="meta-grid">
            <div class="meta-item"><label>Target</label><span>{scan.target}</span></div>
            <div class="meta-item"><label>Module</label><span>{scan.module.value}</span></div>
            <div class="meta-item"><label>Date</label><span>{scan.start_time.strftime('%Y-%m-%d %H:%M UTC')}</span></div>
            <div class="meta-item"><label>Total Findings</label><span>{len(findings)}</span></div>
        </div>
        <div class="summary-box">
            <h3 style="margin-top: 0; color: #166534; font-size: 16px;">Executive Summary</h3>
            <p style="margin-bottom: 0; font-size: 14px; color: #1e293b;">{exec_summary}</p>
        </div>
        <h2>Detailed Findings ({len(findings)})</h2>
        {html_findings if html_findings else '<p style="color: #64748b; font-style: italic;">No vulnerability findings recorded for this assessment.</p>'}
        <div style="margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 20px; font-size: 12px; color: #94a3b8; text-align: center;">
            Generated by CYBERGUARD Security Platform &bull; Strictly Confidential &bull; For Authorized Personnel Only
        </div>
    </div>
</body>
</html>
"""

    report = SecurityReport(
        title=report_title,
        scan_id=scan.id,
        user_id=current_user.id,
        module=scan.module.value,
        target=scan.target,
        executive_summary=exec_summary,
        findings_summary=json.dumps(sev_counts),
        html_content=html_doc
    )
    db.add(report)
    db.commit()
    db.refresh(report)

    log_audit_event(
        db=db,
        action="REPORT_GENERATED",
        user_id=current_user.id,
        target_resource=scan.target,
        details=f"Generated report #{report.id}: {report.title}"
    )

    return report

@router.get("/{report_id}/export/html")
def export_report_html(
    report_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    report = db.query(SecurityReport).filter(SecurityReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    return HTMLResponse(
        content=report.html_content or "<h1>Report Content Unavailable</h1>",
        status_code=200,
        headers={"Content-Disposition": f"attachment; filename=cyberguard-report-{report.id}.html"}
    )

@router.get("/{report_id}/export/json")
def export_report_json(
    report_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    report = db.query(SecurityReport).filter(SecurityReport.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    scan = db.query(ScanRecord).filter(ScanRecord.id == report.scan_id).first()
    findings = db.query(SecurityFinding).filter(SecurityFinding.scan_id == report.scan_id).all() if report.scan_id else []

    data = {
        "report_id": report.id,
        "title": report.title,
        "target": report.target,
        "module": report.module,
        "created_at": report.created_at.isoformat(),
        "executive_summary": report.executive_summary,
        "findings_summary": json.loads(report.findings_summary) if report.findings_summary else {},
        "findings": [
            {
                "id": f.id,
                "title": f.title,
                "severity": f.severity.value,
                "affected_component": f.affected_component,
                "description": f.description,
                "evidence": f.evidence,
                "business_impact": f.business_impact,
                "remediation": f.remediation,
                "cwe_id": f.cwe_id,
                "cvss_score": f.cvss_score
            }
            for f in findings
        ]
    }

    return Response(
        content=json.dumps(data, indent=2),
        media_type="application/json",
        headers={"Content-Disposition": f"attachment; filename=cyberguard-report-{report.id}.json"}
    )
