import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "CYBERGUARD"
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = os.getenv("CYBERGUARD_SECRET_KEY", "cyberguard-production-grade-super-secret-key-32chars-min-change-in-prod!")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days session lifetime
    
    # SQLite Database
    SQLITE_DB_PATH: str = os.getenv("SQLITE_DB_PATH", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "cyberguard.db"))
    
    # OWASP ZAP default URL
    ZAP_API_URL: str = os.getenv("ZAP_API_URL", "http://localhost:8080")
    ZAP_API_KEY: str = os.getenv("ZAP_API_KEY", "")

    # Default Target for Practical 5 (Juice Shop)
    DEFAULT_JUICE_SHOP_URL: str = "http://localhost:3000"
    
    # CORS
    BACKEND_CORS_ORIGINS: list = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000"
    ]

    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
