from typing import Optional
from sqlalchemy.orm import Session
from app.models.audit import AuditLog

def log_audit_event(
    db: Session,
    action: str,
    user_id: Optional[int] = None,
    target_resource: Optional[str] = None,
    details: Optional[str] = None,
    ip_address: Optional[str] = None
) -> AuditLog:
    try:
        log = AuditLog(
            user_id=user_id,
            action=action,
            target_resource=target_resource,
            details=details,
            ip_address=ip_address
        )
        db.add(log)
        db.commit()
        db.refresh(log)
        return log
    except Exception as e:
        db.rollback()
        # Non-blocking error handling for audit logging
        print(f"[AUDIT_ERROR] Failed to write audit log: {e}")
        return None
