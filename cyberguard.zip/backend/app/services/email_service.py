import re
import json
import email
from email import policy
from email.parser import BytesParser
import urllib.parse
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional
import dns.resolver
from sqlalchemy.orm import Session
from app.models.scan import ScanRecord, SecurityFinding, ScanModule, ScanStatus, FindingSeverity
from app.models.email_scan import EmailAnalysisRecord
from app.models.user import User
from app.services.audit_service import log_audit_event

def extract_domain(email_address: str) -> Optional[str]:
    if not email_address:
        return None
    match = re.search(r'@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', email_address)
    if match:
        return match.group(1).lower()
    return None

def check_spf(domain: str) -> Dict[str, Any]:
    if not domain:
        return {"status": "NONE", "details": "No valid domain extracted from sender address."}
    
    try:
        resolver = dns.resolver.Resolver()
        resolver.timeout = 2.0
        resolver.lifetime = 2.5
        answers = resolver.resolve(domain, 'TXT')
        spf_records = []
        for rdata in answers:
            txt_str = "".join([b.decode('utf-8', errors='ignore') if isinstance(b, bytes) else str(b) for b in rdata.strings])
            if txt_str.startswith("v=spf1"):
                spf_records.append(txt_str)
        
        if spf_records:
            return {
                "status": "PASS",
                "details": f"Found valid SPF record: '{spf_records[0]}'",
                "record": spf_records[0]
            }
        else:
            return {
                "status": "NONE",
                "details": f"No 'v=spf1' TXT record found for domain '{domain}'. Senders cannot be verified via SPF.",
                "record": None
            }
    except dns.resolver.NXDOMAIN:
        return {"status": "FAIL", "details": f"Sender domain '{domain}' does not exist (NXDOMAIN)."}
    except dns.resolver.NoAnswer:
        return {"status": "NONE", "details": f"Domain '{domain}' has no TXT DNS records published."}
    except Exception as e:
        return {"status": "ERROR", "details": f"DNS query failed for '{domain}': {str(e)}"}

def check_dkim(msg: email.message.EmailMessage, sender_domain: Optional[str]) -> Dict[str, Any]:
    dkim_header = msg.get("DKIM-Signature")
    if not dkim_header:
        return {
            "status": "NONE",
            "details": "No DKIM-Signature header present in email. Message does not declare cryptographic sender authentication.",
            "selector": None,
            "domain": None
        }

    # Parse DKIM tags (s= selector, d= domain, a= algorithm)
    tags = {}
    for part in dkim_header.split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            tags[k.strip().lower()] = v.strip()

    selector = tags.get("s")
    dkim_domain = tags.get("d") or sender_domain
    algorithm = tags.get("a", "unknown")

    if not selector or not dkim_domain:
        return {
            "status": "UNVERIFIED",
            "details": f"DKIM-Signature present but missing selector (s=) or domain (d=). Raw tags: {list(tags.keys())}",
            "selector": selector,
            "domain": dkim_domain
        }

    # Query public key from DNS: <selector>._domainkey.<domain>
    dns_query = f"{selector}._domainkey.{dkim_domain}"
    try:
        resolver = dns.resolver.Resolver()
        resolver.timeout = 2.0
        resolver.lifetime = 2.5
        answers = resolver.resolve(dns_query, 'TXT')
        dkim_keys = []
        for rdata in answers:
            txt_str = "".join([b.decode('utf-8', errors='ignore') if isinstance(b, bytes) else str(b) for b in rdata.strings])
            if "p=" in txt_str:
                dkim_keys.append(txt_str)

        if dkim_keys:
            return {
                "status": "PASS",
                "details": f"Cryptographic DKIM public key published at '{dns_query}' using algorithm {algorithm}.",
                "selector": selector,
                "domain": dkim_domain,
                "public_key_record": dkim_keys[0][:80] + "..."
            }
        else:
            return {
                "status": "UNVERIFIED",
                "details": f"TXT record found at '{dns_query}' but no public key 'p=' was defined.",
                "selector": selector,
                "domain": dkim_domain
            }
    except dns.resolver.NXDOMAIN:
        return {
            "status": "UNVERIFIED",
            "details": f"DKIM selector DNS record '{dns_query}' does not exist (NXDOMAIN). The key may have been rotated or selector is invalid.",
            "selector": selector,
            "domain": dkim_domain
        }
    except Exception as e:
        return {
            "status": "UNVERIFIED",
            "details": f"Unable to resolve DKIM DNS record '{dns_query}': {str(e)}",
            "selector": selector,
            "domain": dkim_domain
        }

def check_dmarc(domain: str) -> Dict[str, Any]:
    if not domain:
        return {"status": "NONE", "details": "No domain available to query DMARC policy."}
    
    dns_query = f"_dmarc.{domain}"
    try:
        resolver = dns.resolver.Resolver()
        resolver.timeout = 2.0
        resolver.lifetime = 2.5
        answers = resolver.resolve(dns_query, 'TXT')
        dmarc_records = []
        for rdata in answers:
            txt_str = "".join([b.decode('utf-8', errors='ignore') if isinstance(b, bytes) else str(b) for b in rdata.strings])
            if txt_str.startswith("v=DMARC1"):
                dmarc_records.append(txt_str)

        if dmarc_records:
            record = dmarc_records[0]
            # Extract policy
            policy_match = re.search(r'\bp=([a-zA-Z]+)', record)
            p_val = policy_match.group(1).lower() if policy_match else "none"
            
            status_map = {
                "reject": "PASS (REJECT)",
                "quarantine": "PASS (QUARANTINE)",
                "none": "MONITORING (NONE)"
            }

            return {
                "status": status_map.get(p_val, "PASS"),
                "policy": p_val,
                "details": f"DMARC record published with policy p={p_val}. Full: '{record}'",
                "record": record
            }
        else:
            return {
                "status": "NONE",
                "details": f"No 'v=DMARC1' policy record published at '{dns_query}'.",
                "record": None
            }
    except dns.resolver.NXDOMAIN:
        return {"status": "NONE", "details": f"No DMARC record at '{dns_query}'. Domain has not adopted DMARC alignment."}
    except Exception as e:
        return {"status": "ERROR", "details": f"DMARC DNS lookup error for '{domain}': {str(e)}"}

def extract_links_and_text(msg: email.message.EmailMessage) -> Dict[str, Any]:
    body_text = ""
    links = []
    
    if msg.is_multipart():
        for part in msg.walk():
            ctype = part.get_content_type()
            cdispo = str(part.get('Content-Disposition'))
            if 'attachment' not in cdispo:
                payload = part.get_payload(decode=True)
                if payload:
                    decoded = payload.decode('utf-8', errors='ignore')
                    body_text += " " + decoded
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            body_text = payload.decode('utf-8', errors='ignore')

    # Regex find all URLs
    raw_urls = re.findall(r'https?://[^\s<>"]+|www\.[^\s<>"]+', body_text)
    for u in raw_urls:
        links.append(u.rstrip('.,;)'))

    # Extract HTML links with anchor text if available
    html_anchors = re.findall(r'<a\s+(?:[^>]*?\s+)?href=["\'](http[^"\']+)["\'][^>]*>(.*?)</a>', body_text, re.IGNORECASE)
    
    return {
        "text": body_text,
        "links": list(set(links)),
        "anchors": html_anchors
    }

def analyze_phishing_heuristics(
    msg: email.message.EmailMessage,
    spf_res: Dict[str, Any],
    dkim_res: Dict[str, Any],
    dmarc_res: Dict[str, Any],
    links_info: Dict[str, Any]
) -> Dict[str, Any]:
    indicators = []
    score = 0.0

    from_header = str(msg.get("From", ""))
    reply_to = str(msg.get("Reply-To", ""))
    return_path = str(msg.get("Return-Path", ""))
    subject = str(msg.get("Subject", ""))

    from_domain = extract_domain(from_header)
    reply_to_domain = extract_domain(reply_to)
    return_path_domain = extract_domain(return_path)

    # 1. Domain Mismatch Analysis
    if from_domain and reply_to_domain and from_domain != reply_to_domain:
        score += 25.0
        indicators.append({
            "type": "HEADER_MISMATCH",
            "severity": "HIGH",
            "name": "Sender & Reply-To Domain Discrepancy",
            "detail": f"Sender domain '{from_domain}' differs from Reply-To address domain '{reply_to_domain}'. Replies will be routed to a separate domain."
        })

    if from_domain and return_path_domain and from_domain != return_path_domain:
        score += 15.0
        indicators.append({
            "type": "ENVELOPE_MISMATCH",
            "severity": "MEDIUM",
            "name": "Envelope Return-Path Alignment Mismatch",
            "detail": f"From domain '{from_domain}' does not align with bounce Return-Path '{return_path_domain}'."
        })

    # 2. Display Name Spoofing
    if any(brand in from_header.lower() for brand in ["paypal", "microsoft", "google", "apple", "amazon", "bank", "support", "security", "it-desk"]):
        if from_domain and not any(legit in from_domain for legit in ["paypal.com", "microsoft.com", "google.com", "apple.com", "amazon.com"]):
            score += 35.0
            indicators.append({
                "type": "BRAND_IMPERSONATION",
                "severity": "CRITICAL",
                "name": "High-Value Brand Impersonation in Sender Header",
                "detail": f"Header claims to represent a recognized brand/support service ('{from_header}'), but originates from unaligned domain '{from_domain}'."
            })

    # 3. Urgency and Credential Lures in Subject / Body
    urgency_terms = [
        "urgent", "action required", "account suspended", "immediate verification",
        "password reset", "unauthorized login", "payment overdue", "wire transfer",
        "confirm your identity", "security alert", "suspended within 24 hours"
    ]
    detected_urgency = [term for term in urgency_terms if term in subject.lower() or term in links_info["text"][:1500].lower()]
    if detected_urgency:
        score += 20.0
        indicators.append({
            "type": "PSYCHOLOGICAL_URGENCY",
            "severity": "MEDIUM",
            "name": "Coercive Psychological Urgency Detected",
            "detail": f"Message contains high-pressure phrases typically used to bypass user caution: '{', '.join(detected_urgency[:3])}'."
        })

    # 4. Link & URL Inspection
    for link in links_info["links"]:
        # Check IP address in URL
        if re.search(r'https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', link):
            score += 30.0
            indicators.append({
                "type": "IP_HOST_URL",
                "severity": "HIGH",
                "name": "Direct IP Address in Hyperlink",
                "detail": f"Email body links directly to a numeric IP address ('{link}') rather than a registered domain name."
            })
            break

        # Check suspicious TLDs
        suspicious_tlds = [".xyz", ".top", ".click", ".buzz", ".work", ".cfd", ".monster", ".fit", ".rest"]
        if any(link.lower().endswith(tld) or f"{tld}/" in link.lower() for tld in suspicious_tlds):
            score += 15.0
            indicators.append({
                "type": "SUSPICIOUS_TLD",
                "severity": "MEDIUM",
                "name": "Link Directed to Low-Reputation TLD",
                "detail": f"Message contains link directed to a frequently abused top-level domain: {link}"
            })
            break

    # 5. Anchor text mismatch
    for href, anchor_text in links_info.get("anchors", []):
        clean_text = anchor_text.strip()
        if clean_text.startswith("http") or "www." in clean_text:
            text_domain = extract_domain(clean_text)
            href_domain = extract_domain(href)
            if text_domain and href_domain and text_domain != href_domain:
                score += 35.0
                indicators.append({
                    "type": "DECEPTIVE_ANCHOR",
                    "severity": "CRITICAL",
                    "name": "Deceptive Hyperlink Anchor Text",
                    "detail": f"Anchor text displays '{clean_text}', but the actual link destination leads to '{href}'."
                })
                break

    # 6. Absence of Authentication Mechanisms
    if spf_res["status"] in ["NONE", "FAIL"]:
        score += 10.0
    if dkim_res["status"] == "NONE":
        score += 10.0
    if dmarc_res["status"] == "NONE":
        score += 10.0

    # Cap score at 100
    final_score = min(score, 100.0)

    return {
        "score": final_score,
        "indicators": indicators,
        "risk_level": "HIGH" if final_score >= 60 else "MEDIUM" if final_score >= 30 else "LOW"
    }

def analyze_email_file(
    db: Session,
    raw_content: bytes,
    filename: str,
    user: User
) -> ScanRecord:
    """
    Parses an RFC822 .eml file, executes DNS auth verification, evaluates phishing heuristics,
    and commits findings and records to SQLite.
    """
    # Create Scan Record
    scan = ScanRecord(
        user_id=user.id,
        module=ScanModule.EMAIL,
        target=filename,
        scan_type="EMAIL_RFC822_ANALYSIS",
        status=ScanStatus.RUNNING,
        start_time=datetime.now(timezone.utc)
    )
    db.add(scan)
    db.commit()
    db.refresh(scan)

    try:
        # Parse email message
        msg = BytesParser(policy=policy.default).parsebytes(raw_content)

        sender = str(msg.get("From", "Unknown"))
        recipient = str(msg.get("To", "Unknown"))
        subject = str(msg.get("Subject", "(No Subject)"))
        reply_to = str(msg.get("Reply-To", ""))
        return_path = str(msg.get("Return-Path", ""))
        message_id = str(msg.get("Message-ID", ""))

        sender_domain = extract_domain(sender) or extract_domain(return_path)

        # 1. DNS Authentication Checks
        spf_res = check_spf(sender_domain)
        dkim_res = check_dkim(msg, sender_domain)
        dmarc_res = check_dmarc(sender_domain)

        # 2. Extract links and text
        links_info = extract_links_and_text(msg)

        # 3. Phishing Heuristics Engine
        phishing = analyze_phishing_heuristics(msg, spf_res, dkim_res, dmarc_res, links_info)

        # Extract received hops
        received_headers = msg.get_all("Received", [])
        received_chain = [str(r).strip() for r in received_headers]

        # Extract headers json
        headers_dict = {}
        for k, v in msg.items():
            if k not in headers_dict:
                headers_dict[k] = str(v)

        # Create EmailAnalysisRecord
        email_record = EmailAnalysisRecord(
            scan_id=scan.id,
            sender=sender,
            recipient=recipient,
            reply_to=reply_to,
            return_path=return_path,
            subject=subject,
            message_id=message_id,
            spf_status=spf_res["status"],
            spf_details=spf_res["details"],
            dkim_status=dkim_res["status"],
            dkim_details=dkim_res["details"],
            dmarc_status=dmarc_res["status"],
            dmarc_details=dmarc_res["details"],
            phishing_score=phishing["score"],
            phishing_indicators=json.dumps(phishing["indicators"]),
            headers_json=json.dumps(headers_dict),
            received_chain_json=json.dumps(received_chain)
        )
        db.add(email_record)

        # Generate Security Findings based on indicators
        findings_count = 0
        for ind in phishing["indicators"]:
            findings_count += 1
            db_finding = SecurityFinding(
                scan_id=scan.id,
                title=ind["name"],
                severity=FindingSeverity.HIGH if ind["severity"] == "CRITICAL" else FindingSeverity.MEDIUM if ind["severity"] == "HIGH" else FindingSeverity.LOW,
                description=ind["detail"],
                evidence=f"Header: From: {sender} | Reply-To: {reply_to}",
                affected_component="Email Headers / Transport",
                business_impact="Recipient is exposed to credential theft, spear-phishing, or financial fraud.",
                remediation="Configure strict SPF -all, generate DKIM signatures, and enforce DMARC p=reject policy.",
                cwe_id="CWE-290",
                cvss_score=7.1 if ind["severity"] in ["CRITICAL", "HIGH"] else 4.3
            )
            db.add(db_finding)

        # If DMARC missing, add informative finding
        if dmarc_res["status"] == "NONE":
            findings_count += 1
            db.add(SecurityFinding(
                scan_id=scan.id,
                title="Sender Domain Lacks DMARC Enforcement Policy",
                severity=FindingSeverity.MEDIUM,
                description=f"The sender domain '{sender_domain}' has not deployed a DMARC policy record. Mail servers receiving unauthorized messages claiming to originate from this domain cannot verify whether to accept or drop the mail.",
                evidence=dmarc_res["details"],
                affected_component="DMARC Policy",
                business_impact="Attackers can spoof the sender domain without mail servers applying reject or quarantine rules.",
                remediation=f"Publish a TXT record at '_dmarc.{sender_domain}' specifying 'v=DMARC1; p=reject; rua=mailto:dmarc-reports@{sender_domain}'.",
                cwe_id="CWE-346",
                cvss_score=5.3
            ))

        scan.status = ScanStatus.COMPLETED
        scan.completion_time = datetime.now(timezone.utc)
        scan.findings_count = findings_count
        scan.summary = f"Email '{filename}' analyzed. From: {sender}. Risk Score: {phishing['score']}/100 ({phishing['risk_level']}). SPF: {spf_res['status']}, DKIM: {dkim_res['status']}, DMARC: {dmarc_res['status']}."
        
        db.commit()
        db.refresh(scan)

        log_audit_event(
            db=db,
            action="EMAIL_ANALYSIS_COMPLETED",
            user_id=user.id,
            target_resource=filename,
            details=f"Email analysis completed. Sender: {sender}, Score: {phishing['score']}"
        )

        return scan

    except Exception as e:
        scan.status = ScanStatus.FAILED
        scan.completion_time = datetime.now(timezone.utc)
        scan.summary = f"Failed to parse email file: {str(e)}"
        db.commit()
        log_audit_event(
            db=db,
            action="EMAIL_ANALYSIS_FAILED",
            user_id=user.id,
            target_resource=filename,
            details=str(e)
        )
        raise e
