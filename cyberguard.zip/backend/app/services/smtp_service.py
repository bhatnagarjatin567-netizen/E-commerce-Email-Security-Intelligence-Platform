import smtplib
import socket
import ssl
import threading
import time
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional
from aiosmtpd.controller import Controller
from aiosmtpd.handlers import Message
from sqlalchemy.orm import Session
from app.models.scan import ScanRecord, SecurityFinding, ScanModule, ScanStatus, FindingSeverity
from app.models.user import User
from app.services.audit_service import log_audit_event

LAB_SMTP_HOST = "127.0.0.1"
LAB_SMTP_PORT = 10225  # High port safe on Windows without admin elevation

class LabEmailHandler:
    def __init__(self):
        self.received_messages = []

    async def handle_DATA(self, server, session, envelope):
        self.received_messages.append({
            "mail_from": envelope.mail_from,
            "rcpt_tos": envelope.rcpt_tos,
            "content": envelope.content.decode('utf-8', errors='ignore'),
            "peer": session.peer,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        return '250 Message accepted for delivery in CYBERGUARD lab'

# Singleton controller instance
_lab_controller: Optional[Controller] = None
_lab_handler: Optional[LabEmailHandler] = None
_controller_lock = threading.Lock()

def ensure_lab_server_running():
    global _lab_controller, _lab_handler
    with _controller_lock:
        if _lab_controller is None:
            _lab_handler = LabEmailHandler()
            _lab_controller = Controller(
                _lab_handler,
                hostname=LAB_SMTP_HOST,
                port=LAB_SMTP_PORT
            )
            _lab_controller.start()
            # Give server 100ms to bind
            time.sleep(0.1)

def get_lab_server_status() -> Dict[str, Any]:
    global _lab_controller, _lab_handler
    is_running = _lab_controller is not None
    messages_count = len(_lab_handler.received_messages) if _lab_handler else 0
    return {
        "status": "RUNNING" if is_running else "STOPPED",
        "host": LAB_SMTP_HOST,
        "port": LAB_SMTP_PORT,
        "captured_messages_count": messages_count
    }

class TranscriptSMTP(smtplib.SMTP):
    """
    Subclass that captures raw client/server line exchange for audit visualization.
    """
    def __init__(self, *args, **kwargs):
        self.transcript = []
        super().__init__(*args, **kwargs)

    def send(self, s):
        decoded = s.decode('utf-8', errors='ignore') if isinstance(s, bytes) else str(s)
        for line in decoded.splitlines():
            if line.strip():
                self.transcript.append({"direction": "CLIENT -> SERVER", "text": line})
        return super().send(s)

    def getreply(self):
        code, msg = super().getreply()
        decoded_msg = msg.decode('utf-8', errors='ignore') if isinstance(msg, bytes) else str(msg)
        self.transcript.append({
            "direction": "SERVER -> CLIENT",
            "text": f"{code} {decoded_msg}".strip()
        })
        return code, msg

def run_plaintext_smtp_demo(
    db: Session,
    user: User,
    sender: str = "analyst@cyberguard.local",
    recipient: str = "audit-target@cyberguard.local",
    subject: str = "Security Assessment Wire Transmission",
    body: str = "CYBERGUARD Lab Test: Plaintext SMTP communication sample."
) -> Dict[str, Any]:
    ensure_lab_server_running()

    scan = ScanRecord(
        user_id=user.id,
        module=ScanModule.SMTP_LAB,
        target=f"{LAB_SMTP_HOST}:{LAB_SMTP_PORT}",
        scan_type="PLAINTEXT_SMTP_DEMO",
        status=ScanStatus.RUNNING,
        start_time=datetime.now(timezone.utc)
    )
    db.add(scan)
    db.commit()
    db.refresh(scan)

    message_content = f"From: {sender}\r\nTo: {recipient}\r\nSubject: {subject}\r\nDate: {datetime.now().ctime()}\r\n\r\n{body}\r\n"

    transcript = []
    try:
        client = TranscriptSMTP(LAB_SMTP_HOST, LAB_SMTP_PORT, timeout=4.0)
        client.ehlo("cyberguard.local")
        client.sendmail(sender, [recipient], message_content)
        client.quit()
        transcript = client.transcript

        # Create findings explaining the unencrypted nature of plaintext SMTP
        finding = SecurityFinding(
            scan_id=scan.id,
            title="Unencrypted Cleartext SMTP Transmission",
            severity=FindingSeverity.HIGH,
            description="The SMTP conversation was initiated and completed entirely over plaintext TCP without STARTTLS cryptographic wrapping. All envelope addresses, message headers, and body text were visible in cleartext.",
            evidence=f"Transcript contained {len(transcript)} protocol exchanges. Sample: " + transcript[1]["text"] if len(transcript) > 1 else "",
            affected_component="SMTP Protocol Transport (TCP)",
            business_impact="Adversaries positioned on the network path can read sensitive business emails, extract credentials, or inject modified commands.",
            remediation="Enforce mandatory STARTTLS (or Implicit TLS on port 465) with strong cipher suites on all mail transfer agents.",
            cwe_id="CWE-319",
            cvss_score=7.4
        )
        db.add(finding)

        scan.status = ScanStatus.COMPLETED
        scan.completion_time = datetime.now(timezone.utc)
        scan.findings_count = 1
        scan.summary = f"Plaintext SMTP demonstration completed on {LAB_SMTP_HOST}:{LAB_SMTP_PORT}. {len(transcript)} commands exchanged in cleartext."
        db.commit()

        log_audit_event(
            db=db,
            action="SMTP_LAB_PLAINTEXT_RUN",
            user_id=user.id,
            target_resource=f"{LAB_SMTP_HOST}:{LAB_SMTP_PORT}",
            details="Demonstrated unencrypted cleartext SMTP protocol communication in local isolated lab."
        )

        return {
            "scan_id": scan.id,
            "status": "COMPLETED",
            "transcript": transcript,
            "explanation": "Standard legacy SMTP transmits commands as 7-bit ASCII strings over an unencrypted TCP socket. Packet sniffing tools (tcpdump, Wireshark) capture the entire email conversation.",
            "finding": {
                "title": finding.title,
                "severity": finding.severity.value,
                "remediation": finding.remediation
            }
        }
    except Exception as e:
        scan.status = ScanStatus.FAILED
        scan.completion_time = datetime.now(timezone.utc)
        scan.summary = f"Lab error: {str(e)}"
        db.commit()
        raise e

def run_starttls_smtp_demo(
    db: Session,
    user: User,
    target_host: str = "127.0.0.1",
    target_port: int = 10225
) -> Dict[str, Any]:
    """
    Demonstrates STARTTLS capability inspection and TLS negotiation.
    """
    ensure_lab_server_running()

    scan = ScanRecord(
        user_id=user.id,
        module=ScanModule.SMTP_LAB,
        target=f"{target_host}:{target_port}",
        scan_type="STARTTLS_CAPABILITY_AUDIT",
        status=ScanStatus.RUNNING,
        start_time=datetime.now(timezone.utc)
    )
    db.add(scan)
    db.commit()
    db.refresh(scan)

    transcript = []
    try:
        client = TranscriptSMTP(target_host, target_port, timeout=4.0)
        code, msg = client.ehlo("cyberguard.local")
        has_starttls = client.has_extn("STARTTLS")
        transcript = client.transcript.copy()

        if has_starttls:
            context = ssl.create_default_context()
            client.starttls(context=context)
            cipher = client.sock.cipher()
            tls_version = client.sock.version()
            transcript.extend(client.transcript[len(transcript):])
            client.quit()

            finding = SecurityFinding(
                scan_id=scan.id,
                title="STARTTLS Supported and Negotiated",
                severity=FindingSeverity.INFO,
                description=f"Target SMTP server supports opportunistic TLS encryption via STARTTLS. Successfully negotiated {tls_version} using {cipher[0] if cipher else 'Unknown'}.",
                evidence=f"STARTTLS keyword present in EHLO response. Negotiated: {tls_version}",
                affected_component="SMTP STARTTLS Extension",
                business_impact="Traffic encrypted in transit against passive eavesdroppers.",
                remediation="Ensure MTA enforces strong cipher suites and implements MTA-STS / DANE to prevent active downgrade attacks.",
                cwe_id="CWE-310",
                cvss_score=0.0
            )
            db.add(finding)
        else:
            client.quit()
            finding = SecurityFinding(
                scan_id=scan.id,
                title="STARTTLS Extension Not Advertised by Mail Server",
                severity=FindingSeverity.HIGH,
                description=f"The SMTP server at {target_host}:{target_port} does not advertise the STARTTLS extension in response to EHLO. Communications cannot be opportunistically upgraded to TLS.",
                evidence=f"EHLO capabilities returned by {target_host}:{target_port} did not include 'STARTTLS'.",
                affected_component="SMTP Server Capabilities",
                business_impact="All mail relay traffic is transmitted in cleartext, leaving messages vulnerable to interception and modification.",
                remediation="Configure the mail transfer agent to enable STARTTLS with a trusted X.509 certificate.",
                cwe_id="CWE-319",
                cvss_score=7.5
            )
            db.add(finding)

        scan.status = ScanStatus.COMPLETED
        scan.completion_time = datetime.now(timezone.utc)
        scan.findings_count = 1
        scan.summary = f"STARTTLS assessment completed. Supported: {has_starttls}."
        db.commit()

        log_audit_event(
            db=db,
            action="SMTP_LAB_STARTTLS_RUN",
            user_id=user.id,
            target_resource=f"{target_host}:{target_port}",
            details=f"STARTTLS assessment: Supported={has_starttls}"
        )

        return {
            "scan_id": scan.id,
            "status": "COMPLETED",
            "has_starttls": has_starttls,
            "transcript": transcript,
            "explanation": "STARTTLS enables an SMTP connection to convert an existing plaintext TCP channel into an encrypted TLS session. However, because it begins in plaintext, unauthenticated channels are susceptible to STRIPTLS downgrade attacks unless MTA-STS or DANE is enforced."
        }
    except Exception as e:
        scan.status = ScanStatus.FAILED
        scan.completion_time = datetime.now(timezone.utc)
        scan.summary = f"STARTTLS audit error: {str(e)}"
        db.commit()
        raise e

def run_spoofing_smtp_demo(
    db: Session,
    user: User,
    spoofed_sender: str = "executive@trusted-enterprise.com",
    recipient: str = "victim@cyberguard.local",
    subject: str = "CONFIDENTIAL: Immediate Wire Transfer",
    body: str = "Please process this invoice immediately without delay."
) -> Dict[str, Any]:
    """
    Demonstrates envelope sender spoofing strictly inside the isolated local laboratory.
    """
    ensure_lab_server_running()

    scan = ScanRecord(
        user_id=user.id,
        module=ScanModule.SMTP_LAB,
        target=f"localhost (Spoofing Demo: {spoofed_sender})",
        scan_type="SENDER_SPOOFING_MECHANICS",
        status=ScanStatus.RUNNING,
        start_time=datetime.now(timezone.utc)
    )
    db.add(scan)
    db.commit()
    db.refresh(scan)

    message_content = f"From: \"Executive Office\" <{spoofed_sender}>\r\nTo: {recipient}\r\nSubject: {subject}\r\nDate: {datetime.now().ctime()}\r\n\r\n{body}\r\n"

    try:
        client = TranscriptSMTP(LAB_SMTP_HOST, LAB_SMTP_PORT, timeout=4.0)
        client.ehlo("cyberguard.local")
        # Submit arbitrary spoofed envelope sender
        client.sendmail(spoofed_sender, [recipient], message_content)
        client.quit()
        transcript = client.transcript

        # Retrieve the message from local lab handler
        captured = _lab_handler.received_messages[-1] if _lab_handler and _lab_handler.received_messages else None

        finding = SecurityFinding(
            scan_id=scan.id,
            title="Inherent SMTP Protocol Lack of Sender Identity Verification",
            severity=FindingSeverity.HIGH,
            description=f"Standard SMTP accepted arbitrary sender '{spoofed_sender}' without authentication. The receiver accepted the message purely on the client's declared MAIL FROM command.",
            evidence=f"Server returned '250 OK' for spoofed MAIL FROM: <{spoofed_sender}>.",
            affected_component="SMTP Envelope Handshake",
            business_impact="Allows threat actors to impersonate corporate executives, business partners, or vendors (Business Email Compromise).",
            remediation="Implement strict SPF verification (-all), DKIM cryptographic signatures, and enforce a DMARC policy of p=reject on all receiving mail gateways.",
            cwe_id="CWE-290",
            cvss_score=7.5
        )
        db.add(finding)

        scan.status = ScanStatus.COMPLETED
        scan.completion_time = datetime.now(timezone.utc)
        scan.findings_count = 1
        scan.summary = f"Sender spoofing demonstration completed in isolated lab. Spoofed address: {spoofed_sender}."
        db.commit()

        log_audit_event(
            db=db,
            action="SMTP_LAB_SPOOF_DEMO",
            user_id=user.id,
            target_resource="localhost:10225",
            details=f"Demonstrated sender spoofing in isolated lab using {spoofed_sender}"
        )

        return {
            "scan_id": scan.id,
            "status": "COMPLETED",
            "spoofed_sender": spoofed_sender,
            "recipient": recipient,
            "transcript": transcript,
            "captured_in_lab": captured,
            "explanation": "Standard SMTP RFC 5321 was designed without cryptographic authentication. The MAIL FROM command merely informs the receiving MTA where to route bounce messages (NDRs). Unless the receiving MTA performs SPF and DMARC checks, it has no cryptographic proof that the client IP was authorized to send on behalf of that domain.",
            "remediation_summary": "To prevent spoofing: 1) SPF checks IP address authorization, 2) DKIM cryptographically seals message body and headers, 3) DMARC ensures sender alignment and instructs receivers to REJECT unaligned emails."
        }
    except Exception as e:
        scan.status = ScanStatus.FAILED
        scan.completion_time = datetime.now(timezone.utc)
        scan.summary = f"Spoofing demo error: {str(e)}"
        db.commit()
        raise e
