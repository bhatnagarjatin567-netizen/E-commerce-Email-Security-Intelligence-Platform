import ssl
import socket
import urllib.parse
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional
import requests
from sqlalchemy.orm import Session
from app.models.scan import ScanRecord, SecurityFinding, ScanModule, ScanStatus, FindingSeverity
from app.models.user import User
from app.core.config import settings
from app.services.audit_service import log_audit_event

def is_ssrf_safe_url(url: str) -> bool:
    try:
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme not in ["http", "https"]:
            return False
        host = parsed.hostname
        if not host:
            return False
        
        # Block cloud metadata endpoints
        if host in ["169.254.169.254", "metadata.google.internal"]:
            return False
            
        return True
    except Exception:
        return False

def analyze_headers(headers: Dict[str, str], url: str) -> List[Dict[str, Any]]:
    findings = []
    headers_lower = {k.lower(): v for k, v in headers.items()}

    # 1. Content-Security-Policy (CSP)
    csp = headers_lower.get("content-security-policy")
    if not csp:
        findings.append({
            "title": "Missing Content-Security-Policy (CSP) Header",
            "severity": FindingSeverity.HIGH,
            "description": "The web application does not return a Content-Security-Policy HTTP header. CSP is a critical defense-in-depth layer that prevents Cross-Site Scripting (XSS) and data injection attacks by restricting the sources from which scripts, styles, and other resources can be loaded.",
            "evidence": "Response headers lacked 'Content-Security-Policy'. Available headers: " + ", ".join(list(headers.keys())[:8]),
            "affected_component": "HTTP Response Headers",
            "business_impact": "Elevated risk of stored and reflected Cross-Site Scripting (XSS) execution in customer browsers, enabling credential theft or session compromise.",
            "remediation": "Define and deploy a strict Content-Security-Policy header. Example: default-src 'self'; script-src 'self'; object-src 'none';",
            "cwe_id": "CWE-1021",
            "cvss_score": 6.5
        })
    elif "unsafe-inline" in csp or "unsafe-eval" in csp or "* " in csp:
        findings.append({
            "title": "Permissive Directives in Content-Security-Policy",
            "severity": FindingSeverity.MEDIUM,
            "description": "The Content-Security-Policy header includes permissive directives such as 'unsafe-inline', 'unsafe-eval', or wildcard origins, which weaken XSS protections.",
            "evidence": f"CSP: {csp[:160]}...",
            "affected_component": "Content-Security-Policy Header",
            "business_impact": "Attackers can bypass script origin restrictions to execute arbitrary JavaScript if an injection vulnerability exists.",
            "remediation": "Refactor scripts to use cryptographic nonces or hashes rather than 'unsafe-inline' or 'unsafe-eval'.",
            "cwe_id": "CWE-1021",
            "cvss_score": 4.8
        })

    # 2. Strict-Transport-Security (HSTS)
    hsts = headers_lower.get("strict-transport-security")
    parsed_url = urllib.parse.urlparse(url)
    if parsed_url.scheme == "https" and not hsts:
        findings.append({
            "title": "Missing Strict-Transport-Security (HSTS) Header",
            "severity": FindingSeverity.MEDIUM,
            "description": "The HTTPS site does not supply an HSTS header, leaving users vulnerable to SSL-stripping and man-in-the-middle attacks on subsequent visits.",
            "evidence": "HTTPS response does not include 'Strict-Transport-Security'.",
            "affected_component": "HTTP Response Headers",
            "business_impact": "An adversary on the local network could downgrade client connections from HTTPS to plaintext HTTP.",
            "remediation": "Configure HSTS with a minimum max-age of 31536000 seconds (1 year) and includeSubDomains. Example: Strict-Transport-Security: max-age=31536000; includeSubDomains; preload",
            "cwe_id": "CWE-319",
            "cvss_score": 5.4
        })

    # 3. X-Frame-Options (Clickjacking defense)
    xfo = headers_lower.get("x-frame-options")
    if not xfo and not (csp and "frame-ancestors" in csp):
        findings.append({
            "title": "Missing Anti-Clickjacking Header (X-Frame-Options)",
            "severity": FindingSeverity.MEDIUM,
            "description": "The application lacks an X-Frame-Options or CSP frame-ancestors directive, allowing the page to be embedded in malicious iframes.",
            "evidence": "Neither 'X-Frame-Options' nor CSP 'frame-ancestors' was supplied by the target.",
            "affected_component": "HTTP Response Headers",
            "business_impact": "Users can be tricked into performing unintended actions (such as one-click checkout or profile changes) via UI redressing (Clickjacking).",
            "remediation": "Add 'X-Frame-Options: DENY' or 'X-Frame-Options: SAMEORIGIN', or utilize CSP 'frame-ancestors 'self''.",
            "cwe_id": "CWE-1021",
            "cvss_score": 5.0
        })

    # 4. X-Content-Type-Options (MIME sniffing)
    xcto = headers_lower.get("x-content-type-options")
    if xcto != "nosniff":
        findings.append({
            "title": "Missing or Misconfigured X-Content-Type-Options Header",
            "severity": FindingSeverity.LOW,
            "description": "The X-Content-Type-Options header is absent or not set to 'nosniff'. Browsers may attempt to infer the MIME type from the file contents rather than the declared Content-Type header.",
            "evidence": f"X-Content-Type-Options is '{xcto or 'Not Present'}'.",
            "affected_component": "HTTP Response Headers",
            "business_impact": "Can allow user-uploaded files (such as images with embedded script tags) to be executed as HTML/JavaScript in older or non-standard user agents.",
            "remediation": "Ensure all responses send: X-Content-Type-Options: nosniff",
            "cwe_id": "CWE-434",
            "cvss_score": 3.7
        })

    # 5. Referrer-Policy
    ref_pol = headers_lower.get("referrer-policy")
    if not ref_pol:
        findings.append({
            "title": "Missing Referrer-Policy Header",
            "severity": FindingSeverity.LOW,
            "description": "The application does not specify a Referrer-Policy header, causing browsers to use default referrer rules which may leak sensitive URL parameters to external sites.",
            "evidence": "No 'Referrer-Policy' header returned by target.",
            "affected_component": "HTTP Response Headers",
            "business_impact": "Tokens, order IDs, or internal routing paths contained in query strings may be leaked to third-party domains via HTTP Referer headers.",
            "remediation": "Set 'Referrer-Policy: strict-origin-when-cross-origin' or 'no-referrer'.",
            "cwe_id": "CWE-200",
            "cvss_score": 3.3
        })

    # 6. Server banner disclosure
    server_hdr = headers_lower.get("server") or headers_lower.get("x-powered-by")
    if server_hdr:
        findings.append({
            "title": "Server Software Version Disclosure",
            "severity": FindingSeverity.INFO,
            "description": "The target web application reveals technical details regarding underlying server software or runtime environment via HTTP response headers.",
            "evidence": f"Revealed banner: '{server_hdr}'",
            "affected_component": "Server / X-Powered-By Header",
            "business_impact": "Aids potential attackers in footprinting and discovering unpatched known CVEs for the specific web server or framework version.",
            "remediation": "Disable or sanitize the 'Server' and 'X-Powered-By' headers in web server/reverse proxy configuration.",
            "cwe_id": "CWE-200",
            "cvss_score": 2.1
        })

    return findings

def analyze_cookies(cookies: requests.cookies.RequestsCookieJar, raw_set_cookie_headers: List[str]) -> List[Dict[str, Any]]:
    findings = []
    
    # Analyze all cookies received
    for cookie in cookies:
        name = cookie.name
        # Check flags
        is_secure = cookie.secure
        # HttpOnly attribute is stored in _rest or has_nonstandard_attr
        is_httponly = cookie.has_nonstandard_attr("HttpOnly") or "httponly" in [k.lower() for k in cookie._rest.keys()]
        samesite = cookie._rest.get("SameSite") or cookie._rest.get("samesite")

        if not is_httponly:
            findings.append({
                "title": f"Cookie '{name}' Missing HttpOnly Flag",
                "severity": FindingSeverity.HIGH if any(x in name.lower() for x in ["session", "token", "auth", "jwt", "id"]) else FindingSeverity.MEDIUM,
                "description": f"The cookie '{name}' was set without the 'HttpOnly' attribute, making it accessible to client-side scripts via Document.cookie.",
                "evidence": f"Cookie '{name}' does not have HttpOnly flag set.",
                "affected_component": f"Cookie: {name}",
                "business_impact": "If an XSS vulnerability exists on the application, attackers can read and hijack active user sessions or authentication tokens.",
                "remediation": "Append '; HttpOnly' to the Set-Cookie header directive in your session management configuration.",
                "cwe_id": "CWE-1004",
                "cvss_score": 6.8
            })

        if not is_secure:
            findings.append({
                "title": f"Cookie '{name}' Missing Secure Flag",
                "severity": FindingSeverity.HIGH if any(x in name.lower() for x in ["session", "token", "auth", "jwt", "id"]) else FindingSeverity.LOW,
                "description": f"The cookie '{name}' does not have the 'Secure' attribute set, allowing the browser to transmit it over unencrypted HTTP channels.",
                "evidence": f"Cookie '{name}' does not have Secure flag set.",
                "affected_component": f"Cookie: {name}",
                "business_impact": "Adversaries monitoring unencrypted Wi-Fi or network traffic can intercept session cookies via packet sniffing.",
                "remediation": "Configure session cookies with the '; Secure' flag so browsers only transmit them over verified TLS/HTTPS connections.",
                "cwe_id": "CWE-614",
                "cvss_score": 5.9
            })

        if not samesite:
            findings.append({
                "title": f"Cookie '{name}' Missing SameSite Attribute",
                "severity": FindingSeverity.LOW,
                "description": f"The cookie '{name}' does not explicitly declare a 'SameSite' attribute, increasing susceptibility to Cross-Site Request Forgery (CSRF).",
                "evidence": f"Cookie '{name}' missing SameSite flag.",
                "affected_component": f"Cookie: {name}",
                "business_impact": "Browsers may send this cookie on cross-site requests, facilitating CSRF attacks unless explicit anti-CSRF tokens are enforced.",
                "remediation": "Set 'SameSite=Lax' or 'SameSite=Strict' on the Set-Cookie header.",
                "cwe_id": "CWE-1275",
                "cvss_score": 4.3
            })

    return findings

def analyze_tls(target_url: str) -> List[Dict[str, Any]]:
    findings = []
    parsed = urllib.parse.urlparse(target_url)
    hostname = parsed.hostname
    scheme = parsed.scheme

    if scheme == "http":
        # Honest representation: Target requested over plain HTTP
        findings.append({
            "title": "Application Communicating via Unencrypted HTTP",
            "severity": FindingSeverity.HIGH,
            "description": f"The target URL '{target_url}' operates over plaintext HTTP without TLS transport layer security.",
            "evidence": f"Protocol scheme is '{scheme}://' on port {parsed.port or 80}. No cryptographic handshake performed for this connection.",
            "affected_component": "Network Transport Layer",
            "business_impact": "All e-commerce transactions, customer credentials, basket data, and payment details are exposed to interception and tampering in transit.",
            "remediation": "Enforce HTTPS transport encryption across the entire application domain and implement an HTTP-to-HTTPS 301 redirect.",
            "cwe_id": "CWE-319",
            "cvss_score": 7.5
        })
        return findings

    # If HTTPS, inspect certificate using SSL socket
    port = parsed.port or 443
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((hostname, port), timeout=4.0) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                version = ssock.version()
                cipher = ssock.cipher()
                
                # Check TLS version
                if version in ["TLSv1", "TLSv1.1"]:
                    findings.append({
                        "title": f"Deprecated TLS Protocol Version In Use ({version})",
                        "severity": FindingSeverity.HIGH,
                        "description": f"The server negotiated {version}, which is deprecated by RFC 8996 due to known cryptographic weaknesses (POODLE, BEAST).",
                        "evidence": f"Negotiated: {version}, Cipher: {cipher[0] if cipher else 'Unknown'}",
                        "affected_component": "TLS Protocol Configuration",
                        "business_impact": "Exposes traffic to cryptographic downgrade and decryption attacks.",
                        "remediation": "Disable TLS 1.0 and 1.1; enforce TLS 1.2 and TLS 1.3 only.",
                        "cwe_id": "CWE-326",
                        "cvss_score": 7.4
                    })
                else:
                    findings.append({
                        "title": f"TLS Configuration Verified ({version})",
                        "severity": FindingSeverity.INFO,
                        "description": f"The target successfully negotiated a modern TLS session using {version} with cipher suite {cipher[0] if cipher else 'N/A'}.",
                        "evidence": f"Protocol: {version}, Cipher: {cipher[0] if cipher else 'N/A'}, Secret bits: {cipher[2] if cipher else 'N/A'}",
                        "affected_component": "TLS Transport Handshake",
                        "business_impact": "Protects customer traffic from eavesdropping and tampering in transit.",
                        "remediation": "Maintain current cipher configurations and monitor certificate expiration.",
                        "cwe_id": "CWE-310",
                        "cvss_score": 0.0
                    })
    except Exception as e:
        findings.append({
            "title": "TLS Handshake Verification Failed",
            "severity": FindingSeverity.HIGH,
            "description": f"A TLS connection could not be established to {hostname}:{port}: {str(e)}",
            "evidence": str(e),
            "affected_component": "TLS Handshake",
            "business_impact": "Users may encounter invalid certificate warnings or broken encryption.",
            "remediation": "Verify SSL certificate chain, validity dates, and domain name matching.",
            "cwe_id": "CWE-295",
            "cvss_score": 6.5
        })

    return findings

def query_zap_daemon(target_url: str) -> Dict[str, Any]:
    """
    Checks if OWASP ZAP API daemon is reachable and queries baseline alerts.
    If unreachable, returns standby status cleanly.
    """
    zap_url = settings.ZAP_API_URL.rstrip('/')
    api_key = settings.ZAP_API_KEY
    
    try:
        # Check ZAP version
        res = requests.get(f"{zap_url}/JSON/core/view/version/", params={"apikey": api_key}, timeout=1.5)
        if res.status_code == 200:
            version = res.json().get("version", "Active")
            # Query alerts for target
            alerts_res = requests.get(
                f"{zap_url}/JSON/alert/view/alertsByRisk/",
                params={"apikey": api_key, "url": target_url},
                timeout=2.0
            )
            alerts_data = alerts_res.json() if alerts_res.status_code == 200 else {}
            return {
                "available": True,
                "version": version,
                "alerts": alerts_data
            }
    except Exception:
        pass

    return {
        "available": False,
        "status": "OWASP ZAP daemon is in Standby mode. Native Python baseline security tests active."
    }

def run_baseline_probes(target_url: str) -> List[Dict[str, Any]]:
    findings = []
    parsed = urllib.parse.urlparse(target_url)
    base_url = f"{parsed.scheme}://{parsed.netloc}"

    # Check common sensitive e-commerce paths
    probes = [
        {"path": "/.git/HEAD", "title": "Exposed Git Repository Configuration", "severity": FindingSeverity.CRITICAL, "impact": "Complete source code and secret leak"},
        {"path": "/.env", "title": "Exposed Environment Configuration File (.env)", "severity": FindingSeverity.CRITICAL, "impact": "Database credentials and API key disclosure"},
        {"path": "/swagger.json", "title": "Publicly Exposed API Swagger Specification", "severity": FindingSeverity.INFO, "impact": "Exposes full internal API schema and endpoints to reconnaissance"},
        {"path": "/api-docs", "title": "Publicly Accessible API Documentation", "severity": FindingSeverity.INFO, "impact": "Provides attackers with exact endpoint structures and parameters"},
    ]

    for probe in probes:
        try:
            full_probe_url = urllib.parse.urljoin(base_url, probe["path"])
            r = requests.get(full_probe_url, timeout=2.0, allow_redirects=False)
            if r.status_code == 200 and len(r.text) > 0:
                # Extra validation to avoid false positives on SPA catch-alls
                is_false_positive = "<!doctype html" in r.text.lower() and probe["path"] != "/api-docs"
                if not is_false_positive:
                    findings.append({
                        "title": probe["title"],
                        "severity": probe["severity"],
                        "description": f"The sensitive endpoint '{probe['path']}' returned HTTP 200 OK without requiring authentication.",
                        "evidence": f"URL: {full_probe_url} responded with HTTP 200 (Length: {len(r.text)} bytes). Sample: {r.text[:80]}",
                        "affected_component": probe["path"],
                        "business_impact": probe["impact"],
                        "remediation": f"Block public access to '{probe['path']}' via web server configuration or routing rules.",
                        "cwe_id": "CWE-538",
                        "cvss_score": 8.5 if probe["severity"] == FindingSeverity.CRITICAL else 2.5
                    })
        except Exception:
            continue

    return findings

def execute_ecommerce_scan(
    db: Session,
    target_url: str,
    user: User,
    confirm_active: bool = False
) -> ScanRecord:
    """
    Executes a comprehensive, evidence-based e-commerce security assessment.
    """
    if not is_ssrf_safe_url(target_url):
        raise ValueError("Target URL violates security policy or target allowlist.")

    # Create Scan Record
    scan = ScanRecord(
        user_id=user.id,
        module=ScanModule.ECOMMERCE,
        target=target_url,
        scan_type="ACTIVE" if confirm_active else "BASELINE",
        status=ScanStatus.RUNNING,
        start_time=datetime.now(timezone.utc)
    )
    db.add(scan)
    db.commit()
    db.refresh(scan)

    all_findings = []
    
    try:
        # Step 1: Make HTTP request to target
        connected = False
        resp = None
        try:
            resp = requests.get(
                target_url,
                timeout=5.0,
                allow_redirects=True,
                headers={"User-Agent": "CYBERGUARD-Security-Auditor/1.0"}
            )
            connected = True
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as ce:
            all_findings.append({
                "title": "Target Server Unreachable or Connection Refused",
                "severity": FindingSeverity.HIGH,
                "description": f"CYBERGUARD attempted to establish an HTTP connection to '{target_url}', but the host actively refused the connection or timed out. If testing OWASP Juice Shop locally, ensure the Juice Shop service/container is running on the target port.",
                "evidence": f"Socket connection failure: {type(ce).__name__} - {str(ce)[:250]}",
                "affected_component": "Target Host Accessibility",
                "business_impact": "Automated security scanning cannot proceed against an offline or unreachable endpoint.",
                "remediation": "Verify network routing, verify the host firewall, and ensure the target service (e.g. docker run -p 3000:3000 bkimminich/juice-shop) is running.",
                "cwe_id": "CWE-400",
                "cvss_score": 0.0
            })

        if connected and resp is not None:
            # Step 2: HTTP Security Header Analysis
            header_findings = analyze_headers(dict(resp.headers), target_url)
            all_findings.extend(header_findings)

            # Step 3: Cookie Security Analysis
            cookie_findings = analyze_cookies(resp.cookies, resp.raw.headers.getlist("Set-Cookie") if hasattr(resp.raw, "headers") else [])
            all_findings.extend(cookie_findings)

            # Step 4: TLS Transport Security Analysis
            tls_findings = analyze_tls(target_url)
            all_findings.extend(tls_findings)

            # Step 5: Web Baseline Probes
            baseline_findings = run_baseline_probes(target_url)
            all_findings.extend(baseline_findings)

            # Step 6: Query OWASP ZAP (if available)
            zap_info = query_zap_daemon(target_url)
            if zap_info.get("available"):
                # If ZAP reported alerts
                zap_alerts = zap_info.get("alerts", {})
                # Process ZAP alerts if present
                for alert in zap_alerts.get("alerts", []):
                    all_findings.append({
                        "title": f"[ZAP] {alert.get('alert')}",
                        "severity": FindingSeverity.MEDIUM,
                        "description": alert.get("description", "Identified by OWASP ZAP daemon"),
                        "evidence": alert.get("evidence", ""),
                        "affected_component": alert.get("url", target_url),
                        "business_impact": "Identified by OWASP ZAP automated scanner.",
                        "remediation": alert.get("solution", ""),
                        "cwe_id": f"CWE-{alert.get('cweid', '0')}",
                        "cvss_score": 5.0
                    })

        # Save findings to DB
        for item in all_findings:
            db_finding = SecurityFinding(
                scan_id=scan.id,
                title=item["title"],
                severity=item["severity"],
                description=item["description"],
                evidence=item.get("evidence"),
                affected_component=item.get("affected_component"),
                business_impact=item.get("business_impact"),
                remediation=item.get("remediation"),
                cwe_id=item.get("cwe_id"),
                cvss_score=item.get("cvss_score")
            )
            db.add(db_finding)

        scan.status = ScanStatus.COMPLETED
        scan.completion_time = datetime.now(timezone.utc)
        scan.findings_count = len(all_findings)
        scan.summary = f"Assessed {target_url}. Generated {len(all_findings)} confirmed findings across HTTP headers, cookies, TLS, and baseline exposure probes."
        db.commit()
        db.refresh(scan)

        log_audit_event(
            db=db,
            action="SCAN_COMPLETED",
            user_id=user.id,
            target_resource=target_url,
            details=f"E-commerce scan #{scan.id} finished with {len(all_findings)} findings."
        )

        return scan

    except Exception as e:
        scan.status = ScanStatus.FAILED
        scan.completion_time = datetime.now(timezone.utc)
        scan.summary = f"Scan failed during execution: {str(e)}"
        db.commit()
        log_audit_event(
            db=db,
            action="SCAN_FAILED",
            user_id=user.id,
            target_resource=target_url,
            details=str(e)
        )
        raise e
