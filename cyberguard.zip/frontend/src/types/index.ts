export type UserRole = 'ADMIN' | 'ANALYST' | 'VIEWER';
export type AccountStatus = 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'DISABLED';

export interface User {
  id: number;
  email: string;
  full_name: string;
  role: UserRole;
  status: AccountStatus;
  permissions: string;
  is_active: boolean;
  created_at: string;
  updated_at?: string;
}

export type FindingSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';

export interface SecurityFinding {
  id: number;
  scan_id: number;
  title: string;
  severity: FindingSeverity;
  description: string;
  evidence?: string;
  affected_component?: string;
  business_impact?: string;
  remediation?: string;
  cwe_id?: string;
  cvss_score?: number;
  created_at: string;
}

export type ScanModule = 'ECOMMERCE' | 'EMAIL' | 'SMTP_LAB';
export type ScanStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED';

export interface ScanRecord {
  id: number;
  user_id: number;
  module: ScanModule;
  target: string;
  scan_type: string;
  status: ScanStatus;
  start_time: string;
  completion_time?: string;
  findings_count: number;
  summary?: string;
  findings?: SecurityFinding[];
}

export type ScanResponse = ScanRecord;

export interface SecurityReport {
  id: number;
  title: string;
  scan_id?: number;
  user_id: number;
  module: string;
  target: string;
  executive_summary?: string;
  findings_summary?: string;
  html_content?: string;
  created_at: string;
}

export interface AuditLog {
  id: number;
  user_id?: number;
  action: string;
  target_resource?: string;
  details?: string;
  ip_address?: string;
  created_at: string;
}

export interface DashboardOverview {
  stats: {
    total_completed_scans: number;
    total_scans: number;
    total_findings: number;
    severity_counts: Record<FindingSeverity, number>;
    module_counts: Record<string, number>;
  };
  recent_scans: Array<{
    id: number;
    module: string;
    target: string;
    status: string;
    findings_count: number;
    start_time: string;
    completion_time?: string;
  }>;
  recent_reports: Array<{
    id: number;
    title: string;
    module: string;
    target: string;
    created_at: string;
  }>;
  system_status: {
    database: string;
    openssl_installed: boolean;
    zap_daemon: string;
    dns_resolver: string;
    smtp_engine: string;
  };
}

export interface AdminStats {
  total_users: number;
  pending_users: number;
  approved_users: number;
  disabled_users: number;
  rejected_users: number;
  total_scans: number;
  recent_activity: Array<{
    id: number;
    action: string;
    target?: string;
    details?: string;
    created_at: string;
  }>;
}
