import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';
import { User, UserRole } from '../types';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string; status?: string }>;
  register: (fullName: string, email: string, password: string, confirmPassword: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
  hasPermission: (permission: string) => boolean;
  isAdmin: boolean;
  isAnalyst: boolean;
  isViewer: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const savedUser = localStorage.getItem('cyberguard_user');
      return savedUser ? JSON.parse(savedUser) : null;
    } catch {
      return null;
    }
  });
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('cyberguard_token'));
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const checkAuth = async () => {
    const savedToken = localStorage.getItem('cyberguard_token');
    if (!savedToken) {
      setUser(null);
      setToken(null);
      setIsLoading(false);
      return;
    }

    try {
      const response = await api.get('/auth/me');
      setUser(response.data);
      localStorage.setItem('cyberguard_user', JSON.stringify(response.data));
    } catch (error: any) {
      // ONLY clear tokens and state if server explicitly responded with 401 Unauthorized or 403 Forbidden
      if (error.response && (error.response.status === 401 || error.response.status === 403)) {
        console.warn('Session expired or invalidated by server:', error);
        localStorage.removeItem('cyberguard_token');
        localStorage.removeItem('cyberguard_user');
        setUser(null);
        setToken(null);
      } else {
        // Transient network glitch or server offline: preserve local session state
        console.warn('Backend server unreachable during token verification; retaining local credentials.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      const response = await api.post('/auth/login', { email, password });
      const { access_token, user: userData } = response.data;
      
      localStorage.setItem('cyberguard_token', access_token);
      localStorage.setItem('cyberguard_user', JSON.stringify(userData));
      
      setToken(access_token);
      setUser(userData);
      return { success: true };
    } catch (err: any) {
      const status = err.response?.status;
      const detail = err.response?.data?.detail || 'Authentication failed. Please check your credentials.';
      return { success: false, error: detail, status: status?.toString() };
    }
  };

  const register = async (fullName: string, email: string, password: string, confirmPassword: string) => {
    try {
      await api.post('/auth/register', {
        full_name: fullName,
        email,
        password,
        confirm_password: confirmPassword,
      });
      return { success: true };
    } catch (err: any) {
      const detail = err.response?.data?.detail || 'Registration failed. Please try again.';
      return { success: false, error: detail };
    }
  };

  const logout = async () => {
    try {
      if (token) {
        await api.post('/auth/logout');
      }
    } catch (e) {
      // Ignore network errors on logout
    } finally {
      localStorage.removeItem('cyberguard_token');
      localStorage.removeItem('cyberguard_user');
      setUser(null);
      setToken(null);
    }
  };

  const hasPermission = (permission: string): boolean => {
    if (!user) return false;
    if (user.role === 'ADMIN') return true;
    const perms = (user.permissions || '').split(',').map((p) => p.trim());
    return perms.includes(permission);
  };

  const isAdmin = user?.role === 'ADMIN';
  const isAnalyst = user?.role === 'ANALYST';
  const isViewer = user?.role === 'VIEWER';

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user && user.status === 'APPROVED',
        isLoading,
        login,
        register,
        logout,
        checkAuth,
        hasPermission,
        isAdmin,
        isAnalyst,
        isViewer,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
