import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Shield,
  LayoutDashboard,
  ShoppingCart,
  Mail,
  FlaskConical,
  FileText,
  History,
  Users,
  Settings,
  LogOut,
  ChevronRight
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const Sidebar: React.FC = () => {
  const { user, isAdmin, logout } = useAuth();

  const navigation = [
    { name: 'Dashboard', href: '/app', icon: LayoutDashboard },
    { name: 'E-commerce Security', href: '/app/ecommerce', icon: ShoppingCart },
    { name: 'Email Security', href: '/app/email', icon: Mail },
    { name: 'SMTP Laboratory', href: '/app/smtp-lab', icon: FlaskConical },
    { name: 'Reports', href: '/app/reports', icon: FileText },
    { name: 'Scan History', href: '/app/scans', icon: History },
  ];

  if (isAdmin) {
    navigation.push({ name: 'Admin Console', href: '/app/admin', icon: Users });
  }

  navigation.push({ name: 'Settings', href: '/app/settings', icon: Settings });

  return (
    <aside className="w-64 bg-slate-900 flex flex-col justify-between shrink-0 h-screen sticky top-0 border-r border-slate-800">
      <div>
        {/* Logo brand */}
        <div className="h-16 flex items-center px-6 border-b border-slate-800/80">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-brand-500 flex items-center justify-center text-white shadow-sm">
              <Shield className="w-5 h-5 stroke-[2]" />
            </div>
            <div>
              <span className="font-bold text-sm tracking-tight text-white block">
                CYBER<span className="text-brand-400">GUARD</span>
              </span>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-medium">
                Security Intelligence
              </span>
            </div>
          </div>
        </div>

        {/* Navigation list */}
        <div className="px-3 py-4 space-y-1">
          <div className="px-3 pb-2 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
            Main Navigation
          </div>
          {navigation.map((item) => (
            <NavLink
              key={item.name}
              to={item.href}
              end={item.href === '/app'}
              className={({ isActive }) =>
                `flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-brand-600 text-white shadow-sm font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`
              }
            >
              <div className="flex items-center space-x-3">
                <item.icon className="w-4 h-4 shrink-0 stroke-[1.8]" />
                <span>{item.name}</span>
              </div>
            </NavLink>
          ))}
        </div>
      </div>

      {/* User profile & Logout */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/40">
        <div className="flex items-center justify-between p-2 rounded-lg bg-slate-800/40 border border-slate-800">
          <div className="min-w-0 pr-2">
            <p className="text-xs font-medium text-white truncate">{user?.full_name}</p>
            <div className="flex items-center space-x-1.5 mt-0.5">
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded font-semibold tracking-wider ${
                  user?.role === 'ADMIN'
                    ? 'bg-amber-900/40 text-amber-300 border border-amber-700/50'
                    : user?.role === 'ANALYST'
                    ? 'bg-brand-900/40 text-brand-300 border border-brand-700/50'
                    : 'bg-slate-700/50 text-slate-300 border border-slate-600/50'
                }`}
              >
                {user?.role}
              </span>
            </div>
          </div>
          <button
            onClick={() => logout()}
            title="Log out"
            className="p-1.5 text-slate-400 hover:text-red-400 rounded-md hover:bg-slate-800 transition-colors"
          >
            <LogOut className="w-4 h-4 stroke-[1.8]" />
          </button>
        </div>
      </div>
    </aside>
  );
};
