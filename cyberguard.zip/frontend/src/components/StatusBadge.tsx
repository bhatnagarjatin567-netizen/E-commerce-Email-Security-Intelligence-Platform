import React from 'react';
import { AccountStatus, ScanStatus } from '../types';

interface StatusBadgeProps {
  status: AccountStatus | ScanStatus | string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const s = (status || '').toUpperCase();

  const styles: Record<string, string> = {
    // Account statuses
    APPROVED: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    PENDING_APPROVAL: 'bg-amber-50 text-amber-700 border-amber-200',
    REJECTED: 'bg-rose-50 text-rose-700 border-rose-200',
    DISABLED: 'bg-slate-100 text-slate-700 border-slate-200',
    // Scan statuses
    COMPLETED: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    RUNNING: 'bg-sky-50 text-sky-700 border-sky-200 animate-pulse',
    PENDING: 'bg-slate-50 text-slate-600 border-slate-200',
    FAILED: 'bg-rose-50 text-rose-700 border-rose-200',
  };

  const currentStyle = styles[s] || 'bg-slate-50 text-slate-700 border-slate-200';

  return (
    <span className={`inline-flex items-center px-2 py-0.5 text-xs font-medium border rounded-md ${currentStyle}`}>
      {s.replace('_', ' ')}
    </span>
  );
};
