import React from 'react';
import { useAuth } from '../context/AuthContext';
import { ShieldCheck, Bell, Activity } from 'lucide-react';

interface TopHeaderProps {
  title: string;
  subtitle?: string;
}

export const TopHeader: React.FC<TopHeaderProps> = ({ title, subtitle }) => {
  const { user } = useAuth();

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 sm:px-8 flex items-center justify-between sticky top-0 z-40">
      <div>
        <h1 className="text-base font-semibold text-slate-900 tracking-tight">{title}</h1>
        {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
      </div>

      <div className="flex items-center space-x-4">
        {/* Environment status indicator */}
        <div className="hidden sm:flex items-center space-x-2 px-2.5 py-1 rounded-full bg-slate-50 border border-slate-200 text-xs text-slate-600">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="font-medium text-[11px]">System Online</span>
        </div>

        {/* User indicator */}
        <div className="flex items-center space-x-2 pl-2 border-l border-slate-200">
          <div className="w-7 h-7 rounded-full bg-brand-50 border border-brand-200 flex items-center justify-center text-brand-700 text-xs font-semibold">
            {user?.full_name?.charAt(0) || 'U'}
          </div>
          <div className="hidden md:block text-left">
            <span className="text-xs font-medium text-slate-800 block leading-tight">{user?.full_name}</span>
            <span className="text-[10px] text-slate-400 block leading-tight">{user?.email}</span>
          </div>
        </div>
      </div>
    </header>
  );
};
