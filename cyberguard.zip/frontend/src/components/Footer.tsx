import React from 'react';
import { Shield } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center space-x-2">
              <div className="w-7 h-7 rounded-md bg-brand-600 flex items-center justify-center text-white">
                <Shield className="w-4 h-4 stroke-[2]" />
              </div>
              <span className="font-bold text-base tracking-tight text-slate-900">
                CYBER<span className="text-brand-600">GUARD</span>
              </span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Professional cybersecurity intelligence platform for e-commerce security testing, email authentication auditing, and vulnerability assessment.
            </p>
          </div>

          <div>
            <h4 className="text-xs font-semibold text-slate-900 uppercase tracking-wider mb-3">Platform</h4>
            <ul className="space-y-2 text-xs text-slate-600">
              <li><a href="#features" className="hover:text-slate-900 transition-colors">E-commerce Security</a></li>
              <li><a href="#features" className="hover:text-slate-900 transition-colors">Email Authentication</a></li>
              <li><a href="#features" className="hover:text-slate-900 transition-colors">SMTP Laboratory</a></li>
              <li><a href="#features" className="hover:text-slate-900 transition-colors">Vulnerability Reports</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-semibold text-slate-900 uppercase tracking-wider mb-3">Governance</h4>
            <ul className="space-y-2 text-xs text-slate-600">
              <li><a href="#how-it-works" className="hover:text-slate-900 transition-colors">How It Works</a></li>
              <li><a href="#about" className="hover:text-slate-900 transition-colors">About System</a></li>
              <li><span className="text-slate-400">Target Allowlisting</span></li>
              <li><span className="text-slate-400">Audit Compliance</span></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-semibold text-slate-900 uppercase tracking-wider mb-3">Legal & Security</h4>
            <ul className="space-y-2 text-xs text-slate-600">
              <li><span className="hover:text-slate-900 cursor-pointer">Privacy Policy</span></li>
              <li><span className="hover:text-slate-900 cursor-pointer">Terms and Conditions</span></li>
              <li><span className="hover:text-slate-900 cursor-pointer">Security Policy</span></li>
              <li><span className="hover:text-slate-900 cursor-pointer">Responsible Disclosure</span></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center text-xs text-slate-500">
          <p>&copy; {new Date().getFullYear()} CYBERGUARD Security Platform. All rights reserved.</p>
          <p className="mt-2 sm:mt-0">Built for evidence-based cybersecurity assessments.</p>
        </div>
      </div>
    </footer>
  );
};
