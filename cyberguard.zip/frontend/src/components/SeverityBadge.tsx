import React from 'react';
import { FindingSeverity } from '../types';

interface SeverityBadgeProps {
  severity: FindingSeverity | string;
  size?: 'sm' | 'md';
}

export const SeverityBadge: React.FC<SeverityBadgeProps> = ({ severity, size = 'sm' }) => {
  const sev = (severity || 'INFO').toUpperCase();

  const styles: Record<string, string> = {
    CRITICAL: 'bg-red-50 text-red-700 border-red-200',
    HIGH: 'bg-amber-50 text-amber-800 border-amber-200',
    MEDIUM: 'bg-yellow-50 text-yellow-800 border-yellow-200',
    LOW: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    INFO: 'bg-sky-50 text-sky-800 border-sky-200',
  };

  const currentStyle = styles[sev] || styles.INFO;
  const sizeClass = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-sm';

  return (
    <span
      className={`inline-flex items-center font-medium border rounded-md ${currentStyle} ${sizeClass}`}
    >
      <span className="w-1.5 h-1.5 rounded-full mr-1.5 bg-current opacity-70"></span>
      {sev}
    </span>
  );
};
