import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldAlert, ArrowLeft } from 'lucide-react';

export const AccessDeniedPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="w-12 h-12 rounded-full bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center mx-auto mb-4">
          <ShieldAlert className="w-6 h-6 stroke-[1.8]" />
        </div>

        <h2 className="text-2xl font-bold tracking-tight text-slate-900 mb-2">Access Restricted</h2>
        <p className="text-xs text-slate-600 max-w-sm mx-auto mb-6">
          You do not have the required permissions or assigned role to access this module. Please contact your system administrator.
        </p>

        <Link
          to="/app"
          className="inline-flex items-center justify-center px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm"
        >
          <ArrowLeft className="w-3.5 h-3.5 mr-1.5" />
          Back to Dashboard
        </Link>
      </div>
    </div>
  );
};
