import React from 'react';
import { Link } from 'react-router-dom';
import {
  Shield,
  ShoppingCart,
  Mail,
  FlaskConical,
  Search,
  FileText,
  Clock,
  CheckCircle2,
  Lock,
  ArrowRight,
  Server,
  Layers,
  Key
} from 'lucide-react';
import { Navbar } from '../../components/Navbar';
import { Footer } from '../../components/Footer';

export const HomePage: React.FC = () => {
  const features = [
    {
      title: 'E-commerce Security Analysis',
      description: 'Audit modern web and e-commerce platforms. Inspect critical HTTP security headers, cookie flags (Secure, HttpOnly, SameSite), and TLS transport encryption.',
      icon: ShoppingCart,
    },
    {
      title: 'Email Security Analysis',
      description: 'Parse raw .eml RFC822 files. Verify SPF DNS records, validate DKIM signatures, verify DMARC policy compliance, and calculate phishing threat likelihood.',
      icon: Mail,
    },
    {
      title: 'SMTP Security Laboratory',
      description: 'Controlled, isolated local laboratory to analyze SMTP handshakes, test STARTTLS negotiation, and demonstrate spoofing vulnerabilities without sending external mail.',
      icon: FlaskConical,
    },
    {
      title: 'Vulnerability Assessment',
      description: 'Automated baseline checks and OWASP ZAP passive auditing to detect configuration oversights, injection points, and missing defenses with evidence verification.',
      icon: Search,
    },
    {
      title: 'Security Reports',
      description: 'Generate evidence-backed executive and technical assessment reports. Export findings to structured HTML and machine-readable JSON documents.',
      icon: FileText,
    },
    {
      title: 'Scan History and Monitoring',
      description: 'Maintain an immutable historical audit trail of all previous security assessments, target metrics, risk evolution, and administrative decisions.',
      icon: Clock,
    },
  ];

  const steps = [
    {
      step: '01',
      title: 'Register and get authorized access',
      description: 'Create an account and submit your profile for administrator verification and role assignment.',
      icon: Lock,
    },
    {
      step: '02',
      title: 'Select a security assessment module',
      description: 'Choose between E-commerce application scanning, Email message inspection, or the SMTP testing lab.',
      icon: Layers,
    },
    {
      step: '03',
      title: 'Run an assessment and analyse results',
      description: 'Execute targeted assessments against authorized endpoints with real-time evidence generation.',
      icon: Server,
    },
    {
      step: '04',
      title: 'Generate and review security reports',
      description: 'Export structured security reports with severity ratings, CWE IDs, and remediation guidance.',
      icon: FileText,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative pt-20 pb-24 md:pt-28 md:pb-32 bg-white border-b border-slate-200">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            {/* Pill */}
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-brand-50 border border-brand-200/80 text-brand-700 text-xs font-semibold mb-8">
              <Shield className="w-3.5 h-3.5 text-brand-600" />
              <span>Evidence-Based Security Intelligence</span>
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.1] mb-6">
              Security Intelligence for a <br className="hidden sm:inline" />
              <span className="text-brand-600">Safer Digital World</span>
            </h1>

            <p className="max-w-2xl mx-auto text-base sm:text-lg text-slate-600 mb-10 leading-relaxed font-normal">
              Analyse web application vulnerabilities, investigate suspicious emails and strengthen digital security with CYBERGUARD.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link
                to="/register"
                className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 text-sm font-semibold text-white bg-brand-600 hover:bg-brand-700 rounded-lg shadow-sm transition-all"
              >
                Get Started
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
              <a
                href="#features"
                className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg shadow-sm transition-all"
              >
                Explore Features
              </a>
            </div>

            {/* Subtle verification badge row */}
            <div className="mt-16 pt-10 border-t border-slate-100 grid grid-cols-2 md:grid-cols-4 gap-4 text-xs text-slate-500">
              <div className="flex items-center justify-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Zero Fake Scans</span>
              </div>
              <div className="flex items-center justify-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Role-Based Access</span>
              </div>
              <div className="flex items-center justify-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Real Subprocess Tools</span>
              </div>
              <div className="flex items-center justify-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>OWASP Standard Checks</span>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-20 md:py-28 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-xs font-bold text-brand-600 uppercase tracking-widest mb-2">Comprehensive Capabilities</h2>
            <h3 className="text-3xl font-bold text-slate-900 tracking-tight">Security Assessment Modules</h3>
            <p className="mt-3 text-sm text-slate-600">
              Engineered with dedicated analytical engines to detect configuration weaknesses, analyze phishing attempts, and test transport safety.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, idx) => (
              <div
                key={idx}
                className="bg-white p-7 rounded-xl border border-slate-200/90 shadow-sm hover:border-slate-300 transition-all group"
              >
                <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-100 text-brand-600 flex items-center justify-center mb-5 group-hover:bg-brand-50 transition-colors">
                  <feature.icon className="w-5 h-5 stroke-[1.8]" />
                </div>
                <h4 className="text-base font-semibold text-slate-900 mb-2">{feature.title}</h4>
                <p className="text-xs text-slate-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* How It Works Section */}
        <section id="how-it-works" className="py-20 bg-white border-y border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <h2 className="text-xs font-bold text-brand-600 uppercase tracking-widest mb-2">Workflow</h2>
              <h3 className="text-3xl font-bold text-slate-900 tracking-tight">How It Works</h3>
              <p className="mt-3 text-sm text-slate-600">
                A simple, rigorous process to ensure every assessment is authorized, verified, and actionable.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {steps.map((step, idx) => (
                <div key={idx} className="relative">
                  <div className="text-3xl font-black text-slate-200 mb-3">{step.step}</div>
                  <h4 className="text-sm font-semibold text-slate-900 mb-2">{step.title}</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-20 md:py-28 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-900 text-white rounded-2xl p-8 sm:p-12 md:p-16 border border-slate-800 shadow-sm">
            <div className="max-w-3xl">
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-slate-800 text-brand-400 text-xs font-semibold mb-6">
                <Shield className="w-3.5 h-3.5" />
                <span>About CYBERGUARD</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-6 text-white">
                Engineered for Genuine Security Verification
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed mb-6">
                CYBERGUARD was designed from the ground up to eliminate artificial dashboards and fake scan results. Every metric, vulnerability finding, and header analysis is backed by real execution of verified diagnostic tools.
              </p>
              <p className="text-sm text-slate-300 leading-relaxed mb-8">
                With strict administrative oversight, target authorization limits, and granular role-based permissions, the platform serves as a production-grade environment for assessing e-commerce security, examining email communications, and training in safe SMTP configurations.
              </p>

              <div className="flex flex-wrap gap-4 text-xs font-medium text-slate-400">
                <div className="flex items-center space-x-2 bg-slate-800/80 px-3 py-1.5 rounded-md border border-slate-700">
                  <Key className="w-4 h-4 text-brand-400" />
                  <span>Admin Approval Control</span>
                </div>
                <div className="flex items-center space-x-2 bg-slate-800/80 px-3 py-1.5 rounded-md border border-slate-700">
                  <Server className="w-4 h-4 text-brand-400" />
                  <span>Local Juice Shop Target</span>
                </div>
                <div className="flex items-center space-x-2 bg-slate-800/80 px-3 py-1.5 rounded-md border border-slate-700">
                  <FlaskConical className="w-4 h-4 text-brand-400" />
                  <span>Isolated SMTP Lab</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};
