import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Shield, Clock, CheckCircle2, ArrowLeft, Mail } from 'lucide-react';

export const PendingApprovalPage: React.FC = () => {
  const location = useLocation();
  const registeredEmail = (location.state as any)?.registeredEmail;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <Link to="/" className="inline-flex items-center space-x-2.5 mb-4 group">
          <div className="w-9 h-9 rounded-lg bg-brand-600 flex items-center justify-center text-white shadow-sm">
            <Shield className="w-5 h-5 stroke-[2]" />
          </div>
          <span className="font-bold text-xl tracking-tight text-slate-900">
            CYBER<span className="text-brand-600">GUARD</span>
          </span>
        </Link>
      </div>

      <div className="mt-4 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
        <div className="bg-white py-8 px-6 sm:px-10 border border-slate-200/90 rounded-xl shadow-sm text-center">
          <div className="w-12 h-12 rounded-full bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto mb-4">
            <Clock className="w-6 h-6 stroke-[1.8]" />
          </div>

          <h2 className="text-xl font-bold tracking-tight text-slate-900 mb-2">
            Account Pending Approval
          </h2>

          <p className="text-xs text-slate-600 leading-relaxed mb-6">
            Thank you for registering. In accordance with platform governance, all security assessment accounts must be reviewed and authorized by a designated administrator before granting access to scanning tools.
          </p>

          {registeredEmail && (
            <div className="mb-6 p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-700 flex items-center justify-center space-x-2">
              <Mail className="w-4 h-4 text-slate-400" />
              <span className="font-medium">{registeredEmail}</span>
            </div>
          )}

          <div className="bg-slate-50 rounded-lg p-4 text-left border border-slate-200 mb-6 space-y-2.5">
            <h4 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">What happens next?</h4>
            <div className="flex items-start space-x-2 text-xs text-slate-600">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>An administrator will review your account registration.</span>
            </div>
            <div className="flex items-start space-x-2 text-xs text-slate-600">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>Your security role (Analyst or Viewer) and permissions will be assigned.</span>
            </div>
            <div className="flex items-start space-x-2 text-xs text-slate-600">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>Once approved, you can sign in directly with your email and password.</span>
            </div>
          </div>

          <div className="space-y-3">
            <Link
              to="/login"
              className="w-full inline-flex items-center justify-center py-2 px-4 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg shadow-sm transition-colors"
            >
              Return to Sign In
            </Link>
            <Link
              to="/"
              className="inline-flex items-center text-xs text-slate-500 hover:text-slate-800"
            >
              <ArrowLeft className="w-3.5 h-3.5 mr-1" />
              Back to Homepage
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
