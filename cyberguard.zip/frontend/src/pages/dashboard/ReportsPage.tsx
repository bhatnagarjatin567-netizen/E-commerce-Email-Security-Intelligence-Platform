import React, { useEffect, useState } from 'react';
import { FileText, Download, Eye, ExternalLink, Calendar, RefreshCw } from 'lucide-react';
import api from '../../services/api';
import { SecurityReport } from '../../types';
import { TopHeader } from '../../components/TopHeader';
import { EmptyState } from '../../components/EmptyState';

export const ReportsPage: React.FC = () => {
  const [reports, setReports] = useState<SecurityReport[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [previewReport, setPreviewReport] = useState<SecurityReport | null>(null);

  const fetchReports = async () => {
    setLoading(true);
    try {
      const res = await api.get('/reports');
      setReports(res.data);
    } catch (err) {
      console.error('Failed to load reports:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  const downloadHtml = async (reportId: number) => {
    try {
      const response = await api.get(`/reports/${reportId}/export/html`, {
        responseType: 'blob',
      });
      const blob = new Blob([response.data], { type: 'text/html' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `cyberguard-report-${reportId}.html`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to export HTML report:', err);
    }
  };

  const downloadJson = async (reportId: number) => {
    try {
      const response = await api.get(`/reports/${reportId}/export/json`, {
        responseType: 'blob',
      });
      const blob = new Blob([response.data], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `cyberguard-report-${reportId}.json`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to export JSON report:', err);
    }
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-slate-50">
      <TopHeader
        title="Security Assessment Reports"
        subtitle="Formal, evidence-based security findings ready for technical review and compliance export."
      />

      <div className="p-6 sm:p-8 space-y-6 max-w-7xl mx-auto w-full">
        <div className="flex justify-between items-center">
          <p className="text-xs text-slate-600">
            Export assessments in standalone HTML documents or machine-readable JSON schemas.
          </p>
          <button
            onClick={fetchReports}
            className="inline-flex items-center px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-sm transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-xs text-slate-500">Loading reports...</div>
          ) : reports.length === 0 ? (
            <div className="p-6">
              <EmptyState
                icon={FileText}
                title="No Security Reports Generated"
                description="Once an e-commerce, email, or SMTP assessment is completed, generate formal documentation here."
              />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500">
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Report ID & Title</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Module</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Target Endpoint</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Created Date</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px] text-right">Exports</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {reports.map((r) => (
                    <tr key={r.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900">{r.title}</div>
                        <div className="text-[11px] text-slate-400 font-mono">Report #{r.id}</div>
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-slate-700">{r.module}</td>
                      <td className="py-3.5 px-4 text-slate-600 font-mono text-[11px] max-w-xs truncate">{r.target}</td>
                      <td className="py-3.5 px-4 text-slate-500">{new Date(r.created_at).toLocaleDateString()}</td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="inline-flex items-center space-x-1.5">
                          <button
                            onClick={() => setPreviewReport(r)}
                            className="inline-flex items-center px-2 py-1 text-[11px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md"
                          >
                            <Eye className="w-3 h-3 mr-1" /> View
                          </button>
                          <button
                            onClick={() => downloadHtml(r.id)}
                            className="inline-flex items-center px-2 py-1 text-[11px] font-medium text-brand-700 bg-brand-50 hover:bg-brand-100 border border-brand-200 rounded-md"
                          >
                            <Download className="w-3 h-3 mr-1" /> HTML
                          </button>
                          <button
                            onClick={() => downloadJson(r.id)}
                            className="inline-flex items-center px-2 py-1 text-[11px] font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-md"
                          >
                            <Download className="w-3 h-3 mr-1" /> JSON
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Report Preview Modal */}
      {previewReport && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-4xl w-full p-6 shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">{previewReport.title}</h3>
                <p className="text-xs text-slate-500 mt-0.5">Target: {previewReport.target}</p>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => downloadHtml(previewReport.id)}
                  className="px-3 py-1 text-xs font-semibold text-white bg-brand-600 rounded-md"
                >
                  Download HTML
                </button>
                <button
                  onClick={() => setPreviewReport(null)}
                  className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 rounded bg-slate-100"
                >
                  Close
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto border border-slate-200 rounded-lg p-4 bg-slate-50">
              <iframe
                title="Report Preview"
                srcDoc={previewReport.html_content || '<p>No content</p>'}
                className="w-full h-[550px] bg-white rounded border-0"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
