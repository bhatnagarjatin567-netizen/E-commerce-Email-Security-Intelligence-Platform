import React, { useState } from 'react';
import {
  Mail,
  Upload,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  FileText,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Search,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Code
} from 'lucide-react';
import api from '../../services/api';
import { TopHeader } from '../../components/TopHeader';
import { SeverityBadge } from '../../components/SeverityBadge';

export const EmailScanPage: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'HEADERS'>('OVERVIEW');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setError(null);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      setError('Please select an .eml email file to analyze.');
      return;
    }

    setIsAnalyzing(true);
    setError(null);
    setAnalysisResult(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await api.post('/email/analyze', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setAnalysisResult(res.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to analyze email file.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const emailData = analysisResult?.email_analysis;

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-slate-50">
      <TopHeader
        title="Email Security & Authentication Analysis"
        subtitle="RFC822 .eml message parsing, SPF / DKIM / DMARC verification, and phishing threat heuristics."
      />

      <div className="p-6 sm:p-8 space-y-6 max-w-7xl mx-auto w-full">
        {/* File Upload Launcher Card */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg bg-brand-50 border border-brand-100 flex items-center justify-center text-brand-600">
                <Mail className="w-5 h-5 stroke-[1.8]" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-slate-900">Upload Suspicious Email (.eml)</h2>
                <p className="text-xs text-slate-500">
                  Select an exported RFC822 (.eml) message to evaluate SPF records, DKIM selectors, DMARC policies, and phishing indicators.
                </p>
              </div>
            </div>

            <div className="text-xs text-slate-500 font-medium">
              dnspython &bull; email parser active
            </div>
          </div>

          <form onSubmit={handleUpload} className="pt-2 space-y-4">
            <div className="border-2 border-dashed border-slate-200 hover:border-brand-500 p-6 rounded-xl transition-colors bg-slate-50/50 text-center">
              <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <div className="flex items-center justify-center space-x-2 text-xs font-semibold text-slate-700">
                <label className="cursor-pointer text-brand-600 hover:text-brand-700">
                  <span>Browse .eml file</span>
                  <input
                    type="file"
                    accept=".eml,.msg,.txt"
                    onChange={handleFileChange}
                    className="sr-only"
                  />
                </label>
                <span className="text-slate-400">or drag and drop</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                {file ? (
                  <strong className="text-brand-700">{file.name} ({(file.size / 1024).toFixed(1)} KB)</strong>
                ) : (
                  'Supports RFC822 compliant email messages up to 10MB'
                )}
              </p>
            </div>

            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
                {error}
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={!file || isAnalyzing}
                className="inline-flex items-center px-4 py-2 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-700 rounded-lg shadow-sm transition-colors disabled:opacity-50"
              >
                {isAnalyzing ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Parsing & Querying DNS Records...
                  </>
                ) : (
                  <>
                    <Search className="w-3.5 h-3.5 mr-1.5" />
                    Inspect & Analyze Email
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Results Section */}
        {analysisResult && emailData && (
          <div className="space-y-6">
            {/* Top Banner / Actions */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm font-bold text-slate-900">Analysis Complete:</span>
                  <span className="text-xs font-mono text-brand-700 bg-brand-50 px-2 py-0.5 rounded border border-brand-200">
                    {analysisResult.filename}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Subject: <strong className="text-slate-800">{emailData.subject}</strong> &bull; Findings:{' '}
                  <strong className="text-slate-800">{analysisResult.findings_count}</strong>
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <div className="flex bg-slate-100 p-1 rounded-lg">
                  <button
                    onClick={() => setActiveTab('OVERVIEW')}
                    className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                      activeTab === 'OVERVIEW'
                        ? 'bg-white text-slate-900 shadow-sm font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Analysis Overview
                  </button>
                  <button
                    onClick={() => setActiveTab('HEADERS')}
                    className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                      activeTab === 'HEADERS'
                        ? 'bg-white text-slate-900 shadow-sm font-semibold'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Raw Headers ({Object.keys(emailData.headers || {}).length})
                  </button>
                </div>

                <button
                  onClick={async () => {
                    try {
                      await api.post(`/reports/from-scan/${analysisResult.scan_id}`);
                      window.location.assign('/app/reports');
                    } catch (err: any) {
                      alert('Report generation failed.');
                    }
                  }}
                  className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm transition-colors"
                >
                  <FileText className="w-3.5 h-3.5 mr-1.5" />
                  Generate Report
                </button>
              </div>
            </div>

            {activeTab === 'OVERVIEW' ? (
              <>
                {/* Threat Score & Envelope Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Phishing Threat Gauge (1 col) */}
                  <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
                    <div>
                      <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                        Phishing Threat Likelihood
                      </h3>
                      <p className="text-[11px] text-slate-500">
                        Heuristic risk calculated across header alignment, urgency lures, and links.
                      </p>
                    </div>

                    <div className="py-6 text-center">
                      <div className="text-4xl font-extrabold tracking-tight text-slate-900">
                        {emailData.phishing_score}
                        <span className="text-base text-slate-400 font-normal"> / 100</span>
                      </div>
                      <span
                        className={`inline-block mt-2 px-3 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                          emailData.phishing_score >= 60
                            ? 'bg-red-50 text-red-700 border border-red-200'
                            : emailData.phishing_score >= 30
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        }`}
                      >
                        {emailData.phishing_score >= 60
                          ? 'HIGH PROBABLE PHISHING'
                          : emailData.phishing_score >= 30
                          ? 'SUSPICIOUS / CAUTION'
                          : 'LOW / LEGITIMATE'}
                      </span>
                    </div>

                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-2 rounded-full transition-all duration-500 ${
                          emailData.phishing_score >= 60
                            ? 'bg-rose-500'
                            : emailData.phishing_score >= 30
                            ? 'bg-amber-500'
                            : 'bg-emerald-500'
                        }`}
                        style={{ width: `${emailData.phishing_score}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Envelope Header Overview (2 cols) */}
                  <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-3">
                    <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                      Envelope & Message Headers
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                      <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">From (Declared Sender)</span>
                        <span className="font-semibold text-slate-900 font-mono text-[11px] break-all">{emailData.sender}</span>
                      </div>
                      <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Reply-To Address</span>
                        <span className="font-semibold text-slate-900 font-mono text-[11px] break-all">
                          {emailData.reply_to || '(Not Specified)'}
                        </span>
                      </div>
                      <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Return-Path (Bounce Address)</span>
                        <span className="font-semibold text-slate-900 font-mono text-[11px] break-all">
                          {emailData.return_path || '(Not Specified)'}
                        </span>
                      </div>
                      <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Message-ID</span>
                        <span className="font-semibold text-slate-900 font-mono text-[11px] break-all">
                          {emailData.message_id || '(Missing Message-ID)'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 3 Authentication Checks Grid (SPF, DKIM, DMARC) */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  {/* SPF Check */}
                  <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">SPF Verification</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                          emailData.spf_status === 'PASS'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : emailData.spf_status === 'FAIL'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {emailData.spf_status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">{emailData.spf_details}</p>
                    <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-100">
                      Evaluates whether the sending server IP address was authorized by sender domain TXT records.
                    </div>
                  </div>

                  {/* DKIM Check */}
                  <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">DKIM Signature</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                          emailData.dkim_status === 'PASS'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 text-slate-700 border border-slate-200'
                        }`}
                      >
                        {emailData.dkim_status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">{emailData.dkim_details}</p>
                    <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-100">
                      Verifies cryptographic signature validity and DNS public key selector published by the signer.
                    </div>
                  </div>

                  {/* DMARC Check */}
                  <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">DMARC Policy</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                          emailData.dmarc_status.includes('REJECT') || emailData.dmarc_status.includes('QUARANTINE')
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {emailData.dmarc_status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed">{emailData.dmarc_details}</p>
                    <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-100">
                      Confirms alignment rules and specifies disposition policy (reject, quarantine, or none).
                    </div>
                  </div>
                </div>

                {/* Detected Phishing Indicators */}
                <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Detected Threat Indicators ({emailData.phishing_indicators?.length || 0})
                  </h3>

                  {!emailData.phishing_indicators || emailData.phishing_indicators.length === 0 ? (
                    <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-center space-x-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>No suspicious deceptive patterns or phishing lures were flagged in this message.</span>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-100">
                      {emailData.phishing_indicators.map((ind: any, idx: number) => (
                        <div key={idx} className="py-3 flex items-start space-x-3 text-xs">
                          <SeverityBadge severity={ind.severity} />
                          <div>
                            <span className="font-semibold text-slate-900 block">{ind.name}</span>
                            <p className="text-slate-600 text-[11px] mt-0.5 leading-relaxed">{ind.detail}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </>
            ) : (
              /* Raw Headers View */
              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-3">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Complete RFC822 Header Tree
                </h3>
                <div className="max-h-[600px] overflow-y-auto font-mono text-[11px] bg-slate-900 text-slate-200 p-4 rounded-lg space-y-1">
                  {Object.entries(emailData.headers || {}).map(([key, value]: any) => (
                    <div key={key} className="break-all">
                      <span className="text-brand-400 font-semibold">{key}:</span>{' '}
                      <span className="text-slate-300">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
