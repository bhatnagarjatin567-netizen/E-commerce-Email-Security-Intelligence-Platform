import React from 'react';
import { User, Shield, Key, Lock, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { TopHeader } from '../../components/TopHeader';
import { StatusBadge } from '../../components/StatusBadge';

export const UserSettingsPage: React.FC = () => {
  const { user } = useAuth();

  const permissionsList = (user?.permissions || '').split(',').map(p => p.trim()).filter(Boolean);

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-slate-50">
      <TopHeader
        title="Account & Security Settings"
        subtitle="Manage your profile information and review assigned operational permissions."
      />

      <div className="p-6 sm:p-8 space-y-6 max-w-4xl mx-auto w-full">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center space-x-4 pb-6 border-b border-slate-100">
            <div className="w-14 h-14 rounded-full bg-brand-50 border border-brand-200 flex items-center justify-center text-brand-700 text-lg font-bold">
              {user?.full_name?.charAt(0) || 'U'}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">{user?.full_name}</h2>
              <p className="text-xs text-slate-500">{user?.email}</p>
              <div className="flex items-center space-x-2 mt-2">
                <StatusBadge status={user?.status || 'APPROVED'} />
                <span className="text-[11px] font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                  Role: {user?.role}
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
              Assigned Security Capabilities
            </h3>
            <p className="text-xs text-slate-500">
              Permissions are granted by system administrators during registration approval.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {permissionsList.map((perm) => (
                <div key={perm} className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center space-x-2 text-xs">
                  <CheckCircle2 className="w-4 h-4 text-brand-600 shrink-0" />
                  <span className="font-mono text-slate-800">{perm}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
