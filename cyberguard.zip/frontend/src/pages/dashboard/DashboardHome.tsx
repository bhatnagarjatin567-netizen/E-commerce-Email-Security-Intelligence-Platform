import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ShieldCheck,
  AlertTriangle,
  FileText,
  Activity,
  Layers,
  Search,
  ShoppingCart,
  Mail,
  FlaskConical,
  ArrowRight,
  Server,
  RefreshCw
} from 'lucide-react';
import api from '../../services/api';
import { DashboardOverview } from '../../types';
import { TopHeader } from '../../components/TopHeader';
import { StatusBadge } from '../../components/StatusBadge';
import { EmptyState } from '../../components/EmptyState';
import { useAuth } from '../../context/AuthContext';

export const DashboardHome: React.FC = () => {
  const [data, setData] = useState<DashboardOverview | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const { user, isViewer } = useAuth();

  const fetchOverview = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.get('/dashboard/overview');
      setData(res.data);
    } catch (err: any) {
      console.error('Failed to load dashboard metrics:', err);
      setError('Unable to retrieve dashboard metrics from server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOverview();
  }, []);

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-slate-50">
      <TopHeader
        title="Security Intelligence Overview"
        subtitle={`Welcome back, ${user?.full_name}. Real-time security metrics from connected modules.`}
      />

      <div className="p-6 sm:p-8 space-y-8 max-w-7xl mx-auto w-full">
        {/* Top notification / action row */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200/90 shadow-sm">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-lg bg-brand-50 border border-brand-100 flex items-center justify-center text-brand-600">
              <ShieldCheck className="w-5 h-5 stroke-[1.8]" />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-900">Evidence Verification Active</p>
              <p className="text-[11px] text-slate-500">
                All metrics and findings are strictly sourced from SQLite database scan logs.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={fetchOverview}
              disabled={loading}
              className="inline-flex items-center px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${loading ? 'animate-spin' : ''}`} />
              Refresh Data
            </button>
            {!isViewer && (
              <Link
                to="/app/ecommerce"
                className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-700 rounded-lg shadow-sm transition-colors"
              >
                Launch Assessment
                <ArrowRight className="w-3.5 h-3.5 ml-1.5" />
              </Link>
            )}
          </div>
        </div>

        {error && (
          <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
            {error}
          </div>
        )}

        {/* 4 Primary Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Completed Scans</span>
              <div className="w-7 h-7 rounded-md bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-600">
                <Search className="w-4 h-4 stroke-[1.8]" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl font-bold text-slate-900">
                {loading ? '...' : data?.stats.total_completed_scans ?? 0}
              </span>
              <span className="text-xs text-slate-400 ml-2">
                / {loading ? '...' : data?.stats.total_scans ?? 0} total
              </span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Identified Findings</span>
              <div className="w-7 h-7 rounded-md bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600">
                <AlertTriangle className="w-4 h-4 stroke-[1.8]" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl font-bold text-slate-900">
                {loading ? '...' : data?.stats.total_findings ?? 0}
              </span>
              <span className="text-xs text-slate-400 ml-2">across all targets</span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Critical / High Risks</span>
              <div className="w-7 h-7 rounded-md bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600">
                <ShieldCheck className="w-4 h-4 stroke-[1.8]" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl font-bold text-rose-600">
                {loading
                  ? '...'
                  : (data?.stats.severity_counts.CRITICAL || 0) + (data?.stats.severity_counts.HIGH || 0)}
              </span>
              <span className="text-xs text-slate-400 ml-2">immediate action</span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Generated Reports</span>
              <div className="w-7 h-7 rounded-md bg-sky-50 border border-sky-100 flex items-center justify-center text-sky-600">
                <FileText className="w-4 h-4 stroke-[1.8]" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl font-bold text-slate-900">
                {loading ? '...' : data?.recent_reports.length ?? 0}
              </span>
              <span className="text-xs text-slate-400 ml-2">available for export</span>
            </div>
          </div>
        </div>

        {/* Severity Breakdown Bar */}
        <div className="bg-white p-6 rounded-xl border border-slate-200/90 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
                Vulnerability Severity Distribution
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Aggregated breakdown of all confirmed security findings.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {[
              { label: 'Critical', count: data?.stats.severity_counts.CRITICAL || 0, color: 'text-red-700 bg-red-50 border-red-200' },
              { label: 'High', count: data?.stats.severity_counts.HIGH || 0, color: 'text-amber-700 bg-amber-50 border-amber-200' },
              { label: 'Medium', count: data?.stats.severity_counts.MEDIUM || 0, color: 'text-yellow-700 bg-yellow-50 border-yellow-200' },
              { label: 'Low', count: data?.stats.severity_counts.LOW || 0, color: 'text-emerald-700 bg-emerald-50 border-emerald-200' },
              { label: 'Informational', count: data?.stats.severity_counts.INFO || 0, color: 'text-sky-700 bg-sky-50 border-sky-200' },
            ].map((s) => (
              <div key={s.label} className={`p-3 rounded-lg border ${s.color}`}>
                <div className="text-[11px] font-medium opacity-80">{s.label}</div>
                <div className="text-xl font-bold mt-1">{loading ? '-' : s.count}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Two-column layout: Recent Scans & System Status */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Scans (2 cols) */}
          <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200/90 shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
                  Recent Security Assessments
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Latest executed scans across all registered modules.
                </p>
              </div>
              <Link to="/app/scans" className="text-xs font-medium text-brand-600 hover:text-brand-700">
                View All
              </Link>
            </div>

            {loading ? (
              <div className="p-8 text-center text-xs text-slate-500">Loading assessments...</div>
            ) : !data?.recent_scans || data.recent_scans.length === 0 ? (
              <div className="p-6">
                <EmptyState
                  icon={Search}
                  title="No Scans Executed Yet"
                  description="Begin by launching an E-commerce vulnerability scan or analyzing an email .eml file."
                  actionText={!isViewer ? 'Start First Scan' : undefined}
                  onAction={() => window.location.assign('/app/ecommerce')}
                />
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {data.recent_scans.map((scan) => (
                  <div key={scan.id} className="p-4 hover:bg-slate-50/80 transition-colors flex items-center justify-between">
                    <div className="min-w-0 pr-4">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-semibold text-slate-900 truncate">
                          {scan.target}
                        </span>
                        <StatusBadge status={scan.status} />
                      </div>
                      <div className="flex items-center space-x-3 mt-1 text-[11px] text-slate-500">
                        <span>Module: <strong className="text-slate-700">{scan.module}</strong></span>
                        <span>&bull;</span>
                        <span>Findings: <strong className="text-slate-700">{scan.findings_count}</strong></span>
                        <span>&bull;</span>
                        <span>{new Date(scan.start_time).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <Link
                      to={`/app/scans`}
                      className="text-xs font-medium text-slate-500 hover:text-brand-600 shrink-0"
                    >
                      Details &rarr;
                    </Link>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* System Health / Diagnostic Services (1 col) */}
          <div className="bg-white rounded-xl border border-slate-200/90 shadow-sm p-5 space-y-4">
            <div>
              <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
                System Diagnostics
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Backend security engines and local toolchain.
              </p>
            </div>

            <div className="space-y-3 pt-2">
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
                <div>
                  <span className="font-medium text-slate-800 block">Database Storage</span>
                  <span className="text-[11px] text-slate-500">SQLite Engine</span>
                </div>
                <span className="text-emerald-700 font-semibold text-[11px] bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {data?.system_status.database || 'Online'}
                </span>
              </div>

              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
                <div>
                  <span className="font-medium text-slate-800 block">OpenSSL TLS Tool</span>
                  <span className="text-[11px] text-slate-500">Certificate Handshake</span>
                </div>
                <span
                  className={`font-semibold text-[11px] px-2 py-0.5 rounded border ${
                    data?.system_status.openssl_installed
                      ? 'text-emerald-700 bg-emerald-50 border-emerald-200'
                      : 'text-amber-700 bg-amber-50 border-amber-200'
                  }`}
                >
                  {data?.system_status.openssl_installed ? 'Installed' : 'Unavailable'}
                </span>
              </div>

              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
                <div>
                  <span className="font-medium text-slate-800 block">DNS Resolver</span>
                  <span className="text-[11px] text-slate-500">dnspython SPF/DKIM</span>
                </div>
                <span className="text-emerald-700 font-semibold text-[11px] bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {data?.system_status.dns_resolver || 'Ready'}
                </span>
              </div>

              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
                <div>
                  <span className="font-medium text-slate-800 block">OWASP ZAP Engine</span>
                  <span className="text-[11px] text-slate-500">Passive / Active Scan API</span>
                </div>
                <span className="text-slate-700 font-semibold text-[11px] bg-slate-100 px-2 py-0.5 rounded border border-slate-200 text-right max-w-[120px] truncate">
                  {data?.system_status.zap_daemon || 'Standby'}
                </span>
              </div>

              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
                <div>
                  <span className="font-medium text-slate-800 block">SMTP Laboratory</span>
                  <span className="text-[11px] text-slate-500">aiosmtpd Local Engine</span>
                </div>
                <span className="text-emerald-700 font-semibold text-[11px] bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {data?.system_status.smtp_engine || 'Ready'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
