import React, { useEffect, useState } from 'react';
import { History, Filter, Search, Calendar, ChevronRight, AlertCircle, RefreshCw, FileText, ExternalLink } from 'lucide-react';
import api from '../../services/api';
import { ScanRecord, ScanModule, ScanStatus } from '../../types';
import { TopHeader } from '../../components/TopHeader';
import { StatusBadge } from '../../components/StatusBadge';
import { SeverityBadge } from '../../components/SeverityBadge';
import { EmptyState } from '../../components/EmptyState';

export const ScanHistoryPage: React.FC = () => {
  const [scans, setScans] = useState<ScanRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [moduleFilter, setModuleFilter] = useState<string>('ALL');
  const [selectedScan, setSelectedScan] = useState<ScanRecord | null>(null);

  const fetchScans = async () => {
    setLoading(true);
    try {
      const url = moduleFilter !== 'ALL' ? `/scans?module=${moduleFilter}` : '/scans';
      const res = await api.get(url);
      setScans(res.data);
    } catch (err) {
      console.error('Failed to load scan history:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchScans();
  }, [moduleFilter]);

  const handleGenerateReport = async (scanId: number) => {
    try {
      await api.post(`/reports/from-scan/${scanId}`);
      window.location.assign('/app/reports');
    } catch (err: any) {
      alert('Report generation failed.');
    }
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-slate-50">
      <TopHeader
        title="Security Scan History"
        subtitle="Complete chronological audit record of all performed security assessments."
      />

      <div className="p-6 sm:p-8 space-y-6 max-w-7xl mx-auto w-full">
        {/* Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-semibold text-slate-700">Filter Module:</span>
            <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg">
              {['ALL', 'ECOMMERCE', 'EMAIL', 'SMTP_LAB'].map((m) => (
                <button
                  key={m}
                  onClick={() => setModuleFilter(m)}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                    moduleFilter === m
                      ? 'bg-white text-slate-900 shadow-sm font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {m.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={fetchScans}
            className="inline-flex items-center px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>

        {/* Scan List Table */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-xs text-slate-500">Loading scan history...</div>
          ) : scans.length === 0 ? (
            <div className="p-6">
              <EmptyState
                icon={History}
                title="No Scan Records Found"
                description={`No scan assessments have been recorded under the '${moduleFilter}' filter.`}
              />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500">
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Scan ID</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Module</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Target Endpoint</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Status</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Findings</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Execution Time</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px] text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {scans.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-medium text-slate-600">#{s.id}</td>
                      <td className="py-3.5 px-4 font-semibold text-slate-800">{s.module}</td>
                      <td className="py-3.5 px-4 text-slate-700 font-mono text-[11px] max-w-xs truncate">{s.target}</td>
                      <td className="py-3.5 px-4">
                        <StatusBadge status={s.status} />
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-slate-900">{s.findings_count}</span>
                        <span className="text-slate-400 text-[11px] ml-1">issues</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-500">
                        {new Date(s.start_time).toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="inline-flex items-center space-x-1.5">
                          <button
                            onClick={() => setSelectedScan(s)}
                            className="px-2.5 py-1 text-[11px] font-medium text-brand-700 bg-brand-50 hover:bg-brand-100 rounded-md border border-brand-200"
                          >
                            Details
                          </button>
                          <button
                            onClick={() => handleGenerateReport(s.id)}
                            className="px-2 py-1 text-[11px] font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-md shadow-sm"
                            title="Generate Report"
                          >
                            <FileText className="w-3 h-3 inline mr-1" />
                            Report
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Detail Slideout/Modal */}
      {selectedScan && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full p-6 shadow-xl border border-slate-200 space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Scan Record #{selectedScan.id} &bull; {selectedScan.module}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">{selectedScan.target}</p>
              </div>
              <button
                onClick={() => setSelectedScan(null)}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800 px-2.5 py-1 rounded bg-slate-100"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
              <div>
                <span className="text-slate-500 block">Status:</span>
                <span className="font-semibold text-slate-900">{selectedScan.status}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Scan Type:</span>
                <span className="font-semibold text-slate-900">{selectedScan.scan_type}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Start Time:</span>
                <span className="font-semibold text-slate-900">{new Date(selectedScan.start_time).toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Total Findings:</span>
                <span className="font-semibold text-slate-900">{selectedScan.findings_count}</span>
              </div>
            </div>

            {selectedScan.summary && (
              <div className="text-xs text-slate-700 bg-white p-3 rounded-lg border border-slate-200 leading-relaxed">
                <strong>Summary:</strong> {selectedScan.summary}
              </div>
            )}

            {/* Detailed Findings list */}
            {selectedScan.findings && selectedScan.findings.length > 0 && (
              <div className="space-y-2 pt-2">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Attached Findings ({selectedScan.findings.length})
                </h4>
                <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg overflow-hidden bg-white">
                  {selectedScan.findings.map((f: any) => (
                    <div key={f.id} className="p-3 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-900">{f.title}</span>
                        <SeverityBadge severity={f.severity} />
                      </div>
                      <p className="text-slate-600 text-[11px]">{f.description}</p>
                      {f.evidence && (
                        <div className="font-mono text-[10px] text-slate-500 bg-slate-50 p-1.5 rounded">
                          {f.evidence}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end pt-3 border-t border-slate-100">
              <button
                onClick={() => handleGenerateReport(selectedScan.id)}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm"
              >
                Generate Assessment Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
