import React, { useState, useEffect } from 'react';
import {
  FlaskConical,
  Terminal,
  Play,
  Lock,
  Radio,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Layers,
  ArrowRight
} from 'lucide-react';
import api from '../../services/api';
import { TopHeader } from '../../components/TopHeader';

export const SmtpLabPage: React.FC = () => {
  const [labStatus, setLabStatus] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'PLAINTEXT' | 'STARTTLS' | 'SPOOF'>('PLAINTEXT');
  const [isRunning, setIsRunning] = useState(false);
  const [demoResult, setDemoResult] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Form states
  const [plaintextSender, setPlaintextSender] = useState('analyst@cyberguard.local');
  const [plaintextRecipient, setPlaintextRecipient] = useState('audit@target.local');
  const [plaintextSubject, setPlaintextSubject] = useState('Security Assessment Wire Transmission');
  const [plaintextBody, setPlaintextBody] = useState('Sample message demonstrating cleartext transmission over port 10225.');

  const [spoofSender, setSpoofSender] = useState('executive@trusted-enterprise.com');
  const [spoofRecipient, setSpoofRecipient] = useState('finance@cyberguard.local');
  const [spoofSubject, setSpoofSubject] = useState('URGENT: Executive Wire Transfer Authorization');
  const [spoofBody, setSpoofBody] = useState('Please remit $48,000 to vendor account #8912 without delay.');

  const fetchLabStatus = async () => {
    try {
      const res = await api.get('/smtp-lab/status');
      setLabStatus(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchLabStatus();
  }, []);

  const handleRunPlaintext = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsRunning(true);
    setError(null);
    setDemoResult(null);

    try {
      const res = await api.post('/smtp-lab/plaintext-demo', {
        sender: plaintextSender,
        recipient: plaintextRecipient,
        subject: plaintextSubject,
        body: plaintextBody,
      });
      setDemoResult(res.data);
      fetchLabStatus();
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Plaintext demo execution failed.');
    } finally {
      setIsRunning(false);
    }
  };

  const handleRunStarttls = async () => {
    setIsRunning(true);
    setError(null);
    setDemoResult(null);

    try {
      const res = await api.post('/smtp-lab/starttls-demo', {
        host: '127.0.0.1',
        port: 10225,
      });
      setDemoResult(res.data);
      fetchLabStatus();
    } catch (err: any) {
      setError(err.response?.data?.detail || 'STARTTLS demo execution failed.');
    } finally {
      setIsRunning(false);
    }
  };

  const handleRunSpoof = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsRunning(true);
    setError(null);
    setDemoResult(null);

    try {
      const res = await api.post('/smtp-lab/spoof-demo', {
        spoofed_sender: spoofSender,
        recipient: spoofRecipient,
        subject: spoofSubject,
        body: spoofBody,
      });
      setDemoResult(res.data);
      fetchLabStatus();
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Spoof demo execution failed.');
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-slate-50">
      <TopHeader
        title="SMTP Security Laboratory"
        subtitle="Controlled, isolated environment for demonstrating SMTP communication, STARTTLS, and spoofing mechanics."
      />

      <div className="p-6 sm:p-8 space-y-6 max-w-7xl mx-auto w-full">
        {/* Lab Status & Safety Isolation Notice */}
        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start space-x-3">
            <div className="w-9 h-9 rounded-lg bg-amber-50 border border-amber-200 text-amber-700 flex items-center justify-center shrink-0 mt-0.5">
              <FlaskConical className="w-5 h-5 stroke-[1.8]" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-slate-900">Isolated Local Testbed:</span>
                <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {labStatus?.host}:{labStatus?.port} (aiosmtpd)
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                All demonstrations execute strictly on 127.0.0.1. No emails are ever transmitted outside this workstation.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3 text-xs text-slate-600">
            <span>Captured Messages: <strong className="text-slate-900">{labStatus?.captured_messages_count ?? 0}</strong></span>
            <button
              onClick={fetchLabStatus}
              className="p-1.5 text-slate-500 hover:text-slate-800 rounded bg-slate-50 border border-slate-200"
              title="Refresh status"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Experiment Navigation Tabs */}
        <div className="flex space-x-2 bg-slate-200/70 p-1 rounded-xl w-fit">
          <button
            onClick={() => { setActiveTab('PLAINTEXT'); setDemoResult(null); }}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'PLAINTEXT' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>1. Plaintext Wire Visibility</span>
          </button>
          <button
            onClick={() => { setActiveTab('STARTTLS'); setDemoResult(null); }}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'STARTTLS' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>2. STARTTLS Negotiation</span>
          </button>
          <button
            onClick={() => { setActiveTab('SPOOF'); setDemoResult(null); }}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'SPOOF' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>3. Sender Spoofing Mechanics</span>
          </button>
        </div>

        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
            {error}
          </div>
        )}

        {/* TAB 1: PLAINTEXT DEMO */}
        {activeTab === 'PLAINTEXT' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Plaintext SMTP Transmission Test
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Send a test message through the local receiver to inspect the raw wire commands.
                </p>
              </div>

              <form onSubmit={handleRunPlaintext} className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">MAIL FROM</label>
                  <input
                    type="text"
                    value={plaintextSender}
                    onChange={(e) => setPlaintextSender(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 font-mono text-[11px]"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">RCPT TO</label>
                  <input
                    type="text"
                    value={plaintextRecipient}
                    onChange={(e) => setPlaintextRecipient(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 font-mono text-[11px]"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Subject</label>
                  <input
                    type="text"
                    value={plaintextSubject}
                    onChange={(e) => setPlaintextSubject(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Message Body</label>
                  <textarea
                    rows={3}
                    value={plaintextBody}
                    onChange={(e) => setPlaintextBody(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 font-mono text-[11px]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isRunning}
                  className="w-full mt-2 inline-flex items-center justify-center py-2 px-4 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-700 rounded-lg shadow-sm disabled:opacity-50"
                >
                  {isRunning ? 'Transmitting...' : 'Send Over Plaintext Socket'}
                  <Play className="w-3.5 h-3.5 ml-1.5" />
                </button>
              </form>
            </div>

            {/* Transcript & Explanation (2 cols) */}
            <div className="lg:col-span-2 bg-slate-900 rounded-xl border border-slate-800 shadow-sm p-5 flex flex-col justify-between text-xs font-mono text-slate-200">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-slate-400 text-[11px]">
                  <span>Raw SMTP Wire Exchange Transcript</span>
                  <span>Port 10225 &bull; Plaintext TCP</span>
                </div>

                <div className="py-4 space-y-1.5 max-h-[380px] overflow-y-auto">
                  {!demoResult ? (
                    <p className="text-slate-500 italic py-8 text-center font-sans">
                      Click 'Send Over Plaintext Socket' to capture the live client-server socket protocol exchange.
                    </p>
                  ) : (
                    demoResult.transcript?.map((line: any, idx: number) => (
                      <div key={idx} className="flex space-x-2 text-[11px]">
                        <span
                          className={`font-semibold shrink-0 ${
                            line.direction.startsWith('CLIENT') ? 'text-sky-400' : 'text-emerald-400'
                          }`}
                        >
                          {line.direction}:
                        </span>
                        <span className="text-slate-200 break-all">{line.text}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {demoResult && (
                <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700 font-sans text-xs text-slate-300">
                  <strong className="text-white block mb-0.5">Vulnerability Analysis:</strong>
                  {demoResult.explanation}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: STARTTLS DEMO */}
        {activeTab === 'STARTTLS' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  STARTTLS Negotiation Audit
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Probes the SMTP server for the STARTTLS keyword in EHLO responses and initiates TLS upgrade.
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-600 space-y-2">
                <span className="font-semibold text-slate-800 block">How STARTTLS works:</span>
                <p>1. Client connects in cleartext and issues EHLO.</p>
                <p>2. Server advertises supported extensions (e.g. 250-STARTTLS).</p>
                <p>3. Client sends STARTTLS, and both sides initiate TLS handshake.</p>
              </div>

              <button
                onClick={handleRunStarttls}
                disabled={isRunning}
                className="w-full inline-flex items-center justify-center py-2 px-4 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-700 rounded-lg shadow-sm disabled:opacity-50"
              >
                {isRunning ? 'Auditing Extensions...' : 'Audit STARTTLS Handshake'}
                <Play className="w-3.5 h-3.5 ml-1.5" />
              </button>
            </div>

            <div className="lg:col-span-2 bg-slate-900 rounded-xl border border-slate-800 shadow-sm p-5 flex flex-col justify-between text-xs font-mono text-slate-200">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-slate-400 text-[11px]">
                  <span>STARTTLS Handshake Protocol Trace</span>
                  <span>EHLO Extension Discovery</span>
                </div>

                <div className="py-4 space-y-1.5 max-h-[380px] overflow-y-auto">
                  {!demoResult ? (
                    <p className="text-slate-500 italic py-8 text-center font-sans">
                      Click 'Audit STARTTLS Handshake' to query the server's cryptographic capabilities.
                    </p>
                  ) : (
                    demoResult.transcript?.map((line: any, idx: number) => (
                      <div key={idx} className="flex space-x-2 text-[11px]">
                        <span
                          className={`font-semibold shrink-0 ${
                            line.direction.startsWith('CLIENT') ? 'text-sky-400' : 'text-emerald-400'
                          }`}
                        >
                          {line.direction}:
                        </span>
                        <span className="text-slate-200 break-all">{line.text}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {demoResult && (
                <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700 font-sans text-xs text-slate-300">
                  <strong className="text-white block mb-0.5">Assessment Explanation:</strong>
                  {demoResult.explanation}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: SPOOFING DEMO */}
        {activeTab === 'SPOOF' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Sender Spoofing Mechanics Demonstration
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Illustrates why standard SMTP accepts unverified sender identities without SPF/DMARC.
                </p>
              </div>

              <form onSubmit={handleRunSpoof} className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Spoofed Sender Address</label>
                  <input
                    type="text"
                    value={spoofSender}
                    onChange={(e) => setSpoofSender(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 font-mono text-[11px] text-rose-700 bg-rose-50/50"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Target Recipient</label>
                  <input
                    type="text"
                    value={spoofRecipient}
                    onChange={(e) => setSpoofRecipient(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 font-mono text-[11px]"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Subject</label>
                  <input
                    type="text"
                    value={spoofSubject}
                    onChange={(e) => setSpoofSubject(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Deceptive Lure Text</label>
                  <textarea
                    rows={3}
                    value={spoofBody}
                    onChange={(e) => setSpoofBody(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 font-mono text-[11px]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isRunning}
                  className="w-full mt-2 inline-flex items-center justify-center py-2 px-4 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm disabled:opacity-50"
                >
                  {isRunning ? 'Simulating Spoof Attack...' : 'Demonstrate Spoofing Attack'}
                  <Radio className="w-3.5 h-3.5 ml-1.5" />
                </button>
              </form>
            </div>

            <div className="lg:col-span-2 space-y-4">
              {/* Transcript */}
              <div className="bg-slate-900 rounded-xl border border-slate-800 shadow-sm p-5 text-xs font-mono text-slate-200">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-slate-400 text-[11px]">
                  <span>Protocol Interaction: Spoofed MAIL FROM Submission</span>
                  <span className="text-rose-400">Isolated Local Lab</span>
                </div>

                <div className="py-4 space-y-1.5 max-h-[220px] overflow-y-auto">
                  {!demoResult ? (
                    <p className="text-slate-500 italic py-6 text-center font-sans">
                      Click 'Demonstrate Spoofing Attack' to observe standard SMTP's lack of sender validation.
                    </p>
                  ) : (
                    demoResult.transcript?.map((line: any, idx: number) => (
                      <div key={idx} className="flex space-x-2 text-[11px]">
                        <span
                          className={`font-semibold shrink-0 ${
                            line.direction.startsWith('CLIENT') ? 'text-sky-400' : 'text-emerald-400'
                          }`}
                        >
                          {line.direction}:
                        </span>
                        <span className="text-slate-200 break-all">{line.text}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Explanatory Defense Breakdown */}
              {demoResult && (
                <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm text-xs space-y-3">
                  <div className="flex items-center space-x-2 text-slate-900 font-bold">
                    <CheckCircle2 className="w-4 h-4 text-brand-600" />
                    <span>Why did the server accept the spoofed email?</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed text-[11px]">
                    {demoResult.explanation}
                  </p>

                  <div className="p-3 bg-brand-50 border border-brand-200 rounded-lg text-brand-900 text-[11px] leading-relaxed">
                    <strong>The Defense Trio (SPF + DKIM + DMARC):</strong><br />
                    {demoResult.remediation_summary}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
