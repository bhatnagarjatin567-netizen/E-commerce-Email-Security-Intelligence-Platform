import React, { useState, useEffect } from 'react';
import {
  Users,
  CheckCircle,
  XCircle,
  Clock,
  UserX,
  UserCheck,
  Shield,
  Activity,
  Filter,
  Check,
  X,
  AlertCircle,
  RefreshCw
} from 'lucide-react';
import api from '../../services/api';
import { User, AdminStats, AccountStatus, UserRole } from '../../types';
import { TopHeader } from '../../components/TopHeader';
import { StatusBadge } from '../../components/StatusBadge';
import { EmptyState } from '../../components/EmptyState';

export const AdminDashboardPage: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [actionMessage, setActionMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Approval modal state
  const [selectedUserForApproval, setSelectedUserForApproval] = useState<User | null>(null);
  const [approvalRole, setApprovalRole] = useState<UserRole>('ANALYST');
  const [approvalPermissions, setApprovalPermissions] = useState<string>(
    'scan:ecommerce,scan:email,lab:smtp,report:create,report:view'
  );

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const [usersRes, statsRes] = await Promise.all([
        api.get('/admin/users'),
        api.get('/admin/stats'),
      ]);
      setUsers(usersRes.data);
      setStats(statsRes.data);
    } catch (err: any) {
      console.error('Failed to load admin management data:', err);
      setActionMessage({ text: 'Failed to load user management records.', type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handleApprove = async () => {
    if (!selectedUserForApproval) return;
    try {
      await api.post(`/admin/users/${selectedUserForApproval.id}/approve`, {
        status: 'APPROVED',
        role: approvalRole,
        permissions: approvalPermissions,
      });
      setActionMessage({
        text: `Approved account for ${selectedUserForApproval.email} as ${approvalRole}.`,
        type: 'success',
      });
      setSelectedUserForApproval(null);
      fetchAdminData();
    } catch (err: any) {
      setActionMessage({ text: err.response?.data?.detail || 'Approval failed.', type: 'error' });
    }
  };

  const handleReject = async (user: User) => {
    if (!confirm(`Are you sure you want to reject registration for ${user.email}?`)) return;
    try {
      await api.post(`/admin/users/${user.id}/reject`);
      setActionMessage({ text: `Rejected account for ${user.email}.`, type: 'success' });
      fetchAdminData();
    } catch (err: any) {
      setActionMessage({ text: err.response?.data?.detail || 'Action failed.', type: 'error' });
    }
  };

  const handleToggleStatus = async (user: User) => {
    try {
      const res = await api.post(`/admin/users/${user.id}/toggle-status`);
      const newStatus = res.data.status;
      setActionMessage({
        text: `Account for ${user.email} is now ${newStatus}.`,
        type: 'success',
      });
      fetchAdminData();
    } catch (err: any) {
      setActionMessage({ text: err.response?.data?.detail || 'Status toggle failed.', type: 'error' });
    }
  };

  const filteredUsers = users.filter((u) => {
    if (statusFilter === 'ALL') return true;
    return u.status === statusFilter;
  });

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-slate-50">
      <TopHeader
        title="Admin Governance & User Management"
        subtitle="Review registration requests, assign security analyst roles, and inspect immutable audit logs."
      />

      <div className="p-6 sm:p-8 space-y-8 max-w-7xl mx-auto w-full">
        {/* Top message toast */}
        {actionMessage && (
          <div
            className={`p-3.5 rounded-lg border text-xs flex items-center justify-between ${
              actionMessage.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : 'bg-rose-50 border-rose-200 text-rose-800'
            }`}
          >
            <span>{actionMessage.text}</span>
            <button
              onClick={() => setActionMessage(null)}
              className="text-slate-400 hover:text-slate-700 ml-4"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Admin Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Registered Users</span>
              <div className="w-7 h-7 rounded-md bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-600">
                <Users className="w-4 h-4 stroke-[1.8]" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl font-bold text-slate-900">
                {loading ? '...' : stats?.total_users ?? 0}
              </span>
              <span className="text-xs text-slate-400 ml-2">in platform</span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Pending Approvals</span>
              <div className="w-7 h-7 rounded-md bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600">
                <Clock className="w-4 h-4 stroke-[1.8]" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl font-bold text-amber-600">
                {loading ? '...' : stats?.pending_users ?? 0}
              </span>
              <span className="text-xs text-slate-400 ml-2">awaiting review</span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Approved Accounts</span>
              <div className="w-7 h-7 rounded-md bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
                <CheckCircle className="w-4 h-4 stroke-[1.8]" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl font-bold text-slate-900">
                {loading ? '...' : stats?.approved_users ?? 0}
              </span>
              <span className="text-xs text-slate-400 ml-2">active analysts</span>
            </div>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">Disabled Accounts</span>
              <div className="w-7 h-7 rounded-md bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-500">
                <UserX className="w-4 h-4 stroke-[1.8]" />
              </div>
            </div>
            <div className="mt-3">
              <span className="text-2xl font-bold text-slate-900">
                {loading ? '...' : stats?.disabled_users ?? 0}
              </span>
              <span className="text-xs text-slate-400 ml-2">access suspended</span>
            </div>
          </div>
        </div>

        {/* User Management Section */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-sm overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
                User Access & Permissions Directory
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Verify identities, approve analysts, and control module permissions.
              </p>
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center space-x-1.5 bg-slate-100 p-1 rounded-lg">
              {['ALL', 'PENDING_APPROVAL', 'APPROVED', 'DISABLED'].map((s) => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={`px-2.5 py-1 text-[11px] font-medium rounded-md transition-colors ${
                    statusFilter === s
                      ? 'bg-white text-slate-900 shadow-sm font-semibold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {s.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          {loading ? (
            <div className="p-8 text-center text-xs text-slate-500">Loading user accounts...</div>
          ) : filteredUsers.length === 0 ? (
            <div className="p-6">
              <EmptyState
                icon={Users}
                title="No Users Found"
                description={`No accounts match the '${statusFilter}' filter criteria.`}
              />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500">
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">User Name & Email</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Status</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Assigned Role</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px]">Registered</th>
                    <th className="py-3 px-4 font-semibold uppercase tracking-wider text-[11px] text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900">{u.full_name}</div>
                        <div className="text-[11px] text-slate-500">{u.email}</div>
                      </td>
                      <td className="py-3.5 px-4">
                        <StatusBadge status={u.status} />
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium ${
                            u.role === 'ADMIN'
                              ? 'bg-amber-50 text-amber-800 border border-amber-200'
                              : u.role === 'ANALYST'
                              ? 'bg-brand-50 text-brand-800 border border-brand-200'
                              : 'bg-slate-100 text-slate-700 border border-slate-200'
                          }`}
                        >
                          {u.role}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-500">
                        {new Date(u.created_at).toLocaleDateString()}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="inline-flex items-center space-x-1.5">
                          {u.status === 'PENDING_APPROVAL' && (
                            <>
                              <button
                                onClick={() => {
                                  setSelectedUserForApproval(u);
                                  setApprovalRole('ANALYST');
                                }}
                                className="inline-flex items-center px-2.5 py-1 text-[11px] font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-md shadow-sm"
                              >
                                <Check className="w-3 h-3 mr-1" />
                                Review & Approve
                              </button>
                              <button
                                onClick={() => handleReject(u)}
                                className="inline-flex items-center px-2 py-1 text-[11px] font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-md"
                              >
                                <X className="w-3 h-3 mr-1" />
                                Reject
                              </button>
                            </>
                          )}

                          {u.status === 'APPROVED' && u.role !== 'ADMIN' && (
                            <button
                              onClick={() => handleToggleStatus(u)}
                              className="px-2 py-1 text-[11px] font-medium text-slate-700 hover:text-rose-700 hover:bg-rose-50 rounded-md border border-slate-200"
                            >
                              Disable
                            </button>
                          )}

                          {u.status === 'DISABLED' && (
                            <button
                              onClick={() => handleToggleStatus(u)}
                              className="px-2 py-1 text-[11px] font-medium text-emerald-700 hover:bg-emerald-50 rounded-md border border-emerald-200"
                            >
                              Reactivate
                            </button>
                          )}

                          {u.role === 'ADMIN' && (
                            <span className="text-[11px] text-slate-400 italic">Primary Admin</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Audit Log Activity Section */}
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-sm p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider">
                Platform Security Audit Log
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Immutable records of administrative and security actions.
              </p>
            </div>
            <button
              onClick={fetchAdminData}
              className="text-xs text-brand-600 hover:text-brand-700 inline-flex items-center"
            >
              <RefreshCw className="w-3 h-3 mr-1" /> Refresh Logs
            </button>
          </div>

          {!stats?.recent_activity || stats.recent_activity.length === 0 ? (
            <p className="text-xs text-slate-400 italic py-4">No audit events recorded yet.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {stats.recent_activity.map((log) => (
                <div key={log.id} className="py-2.5 flex items-start justify-between text-xs">
                  <div>
                    <span className="font-semibold text-slate-800">{log.action}</span>
                    <span className="text-slate-400 mx-2">&bull;</span>
                    <span className="text-slate-600">{log.details || log.target}</span>
                  </div>
                  <span className="text-[11px] text-slate-400 shrink-0 ml-4">
                    {new Date(log.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Approval Modal */}
      {selectedUserForApproval && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200 space-y-4">
            <h3 className="text-sm font-bold text-slate-900">Approve User Account</h3>
            <p className="text-xs text-slate-600">
              Assign security privileges and operational permissions for{' '}
              <strong>{selectedUserForApproval.email}</strong>.
            </p>

            <div className="space-y-3 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Assigned Role</label>
                <select
                  value={approvalRole}
                  onChange={(e) => setApprovalRole(e.target.value as UserRole)}
                  className="w-full text-xs border border-slate-300 rounded-lg p-2 focus:ring-brand-500 focus:border-brand-500 bg-white"
                >
                  <option value="ANALYST">Security Analyst (Run scans, view results, generate reports)</option>
                  <option value="VIEWER">Viewer (Read-only access to assigned reports and findings)</option>
                  <option value="ADMIN">Administrator (Full application & user management access)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Granted Module Permissions (comma-separated)
                </label>
                <input
                  type="text"
                  value={approvalPermissions}
                  onChange={(e) => setApprovalPermissions(e.target.value)}
                  className="w-full text-xs border border-slate-300 rounded-lg p-2 font-mono text-slate-800 bg-slate-50"
                />
                <span className="text-[10px] text-slate-400 block mt-1">
                  Available: scan:ecommerce, scan:email, lab:smtp, report:create, report:view
                </span>
              </div>
            </div>

            <div className="flex justify-end space-x-2 pt-4 border-t border-slate-100">
              <button
                onClick={() => setSelectedUserForApproval(null)}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleApprove}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm"
              >
                Confirm Approval
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
