import React, { useState } from 'react';
import {
  ShoppingCart,
  ShieldAlert,
  ShieldCheck,
  Play,
  Layers,
  Lock,
  Cookie,
  FileCode,
  Terminal,
  AlertTriangle,
  Info,
  CheckCircle2,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  PlusCircle,
  FileText
} from 'lucide-react';
import api from '../../services/api';
import { ScanResponse, SecurityFinding, FindingSeverity } from '../../types';
import { TopHeader } from '../../components/TopHeader';
import { SeverityBadge } from '../../components/SeverityBadge';
import { useAuth } from '../../context/AuthContext';

export const EcommerceScanPage: React.FC = () => {
  const [targetUrl, setTargetUrl] = useState('http://localhost:3000');
  const [scanType, setScanType] = useState<'BASELINE' | 'ACTIVE'>('BASELINE');
  const [confirmActive, setConfirmActive] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [expandedFinding, setExpandedFinding] = useState<number | null>(null);

  // Manual browser storage observation modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [manualTitle, setManualTitle] = useState('');
  const [manualSeverity, setManualSeverity] = useState<FindingSeverity>('MEDIUM');
  const [manualStorageType, setManualStorageType] = useState('localStorage');
  const [manualDescription, setManualDescription] = useState('');
  const [manualEvidence, setManualEvidence] = useState('');
  const [manualImpact, setManualImpact] = useState('');
  const [manualRemediation, setManualRemediation] = useState('');
  const [submittingManual, setSubmittingManual] = useState(false);

  const { hasPermission } = useAuth();

  const handleStartScan = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsScanning(true);
    setScanResult(null);

    try {
      const res = await api.post('/ecommerce/scan', {
        module: 'ECOMMERCE',
        target: targetUrl,
        scan_type: scanType,
        confirm_active_scan: scanType === 'ACTIVE' ? confirmActive : false,
      });
      setScanResult(res.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'An error occurred during assessment execution.');
    } finally {
      setIsScanning(false);
    }
  };

  const handleAddManualEvidence = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!scanResult) return;
    setSubmittingManual(true);

    try {
      const res = await api.post('/scans/manual-evidence', {
        scan_id: scanResult.id,
        title: manualTitle,
        severity: manualSeverity,
        description: manualDescription,
        evidence: manualEvidence,
        affected_component: `Browser ${manualStorageType}`,
        business_impact: manualImpact,
        remediation: manualRemediation,
      });

      // Append new finding to current scan view
      setScanResult({
        ...scanResult,
        findings_count: scanResult.findings_count + 1,
        findings: [res.data, ...(scanResult.findings || [])],
      });

      setIsModalOpen(false);
      setManualTitle('');
      setManualDescription('');
      setManualEvidence('');
    } catch (err: any) {
      alert(err.response?.data?.detail || 'Failed to add manual evidence.');
    } finally {
      setSubmittingManual(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-slate-50">
      <TopHeader
        title="E-commerce Security Analysis"
        subtitle="Practical 5: Security Vulnerability Analysis of an E-commerce Application (OWASP Juice Shop)."
      />

      <div className="p-6 sm:p-8 space-y-6 max-w-7xl mx-auto w-full">
        {/* Module Launcher Card */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg bg-brand-50 border border-brand-100 flex items-center justify-center text-brand-600">
                <ShoppingCart className="w-5 h-5 stroke-[1.8]" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-slate-900">E-commerce Assessment Engine</h2>
                <p className="text-xs text-slate-500">
                  Audits HTTP response headers, cookie flags (Secure, HttpOnly, SameSite), TLS transport, and baseline exposure.
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2 text-xs text-slate-500">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>Target Ready</span>
            </div>
          </div>

          <form onSubmit={handleStartScan} className="pt-2 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Target Application URL (OWASP Juice Shop / E-commerce App)
                </label>
                <input
                  type="text"
                  required
                  value={targetUrl}
                  onChange={(e) => setTargetUrl(e.target.value)}
                  placeholder="http://localhost:3000"
                  className="w-full text-xs font-mono border border-slate-300 rounded-lg p-2.5 bg-white text-slate-900 focus:ring-brand-500 focus:border-brand-500 shadow-sm"
                />
                <span className="text-[11px] text-slate-500 block mt-1">
                  Default local testbed: <code className="text-brand-700 bg-brand-50 px-1 py-0.5 rounded">http://localhost:3000</code> (OWASP Juice Shop)
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Assessment Type</label>
                <select
                  value={scanType}
                  onChange={(e) => setScanType(e.target.value as any)}
                  className="w-full text-xs border border-slate-300 rounded-lg p-2.5 bg-white text-slate-900 focus:ring-brand-500 focus:border-brand-500 shadow-sm"
                >
                  <option value="BASELINE">Passive Baseline Audit (Safe / Non-intrusive)</option>
                  <option value="ACTIVE">Active Assessment (Probing & Crawling)</option>
                </select>
              </div>
            </div>

            {scanType === 'ACTIVE' && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 flex items-start space-x-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold">Explicit Authorization Required:</span>
                  <p className="mt-0.5 text-amber-800 text-[11px]">
                    Active security assessments send dynamic probes to the target application. Ensure you are authorized to test this system.
                  </p>
                  <label className="flex items-center space-x-2 mt-2 font-medium text-amber-950 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={confirmActive}
                      onChange={(e) => setConfirmActive(e.target.checked)}
                      className="rounded text-brand-600 focus:ring-brand-500 h-3.5 w-3.5"
                    />
                    <span>I confirm I have explicit authorization to perform active testing on this target.</span>
                  </label>
                </div>
              </div>
            )}

            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
                {error}
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={isScanning || (scanType === 'ACTIVE' && !confirmActive)}
                className="inline-flex items-center px-4 py-2 text-xs font-semibold text-white bg-brand-600 hover:bg-brand-700 rounded-lg shadow-sm transition-colors disabled:opacity-50"
              >
                {isScanning ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Executing Security Assessment...
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 mr-1.5" />
                    Launch Security Assessment
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Live Results Section */}
        {scanResult && (
          <div className="space-y-6">
            {/* Overview Banner */}
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-bold text-slate-900">Assessment Complete:</span>
                    <span className="text-xs font-mono text-brand-700 bg-brand-50 px-2 py-0.5 rounded border border-brand-200">
                      {scanResult.target}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Scan ID: #{scanResult.id} &bull; Type: {scanResult.scan_type} &bull; Findings:{' '}
                    <strong className="text-slate-800">{scanResult.findings_count}</strong>
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setIsModalOpen(true)}
                    className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                  >
                    <PlusCircle className="w-3.5 h-3.5 mr-1.5" />
                    Add Browser Storage Evidence
                  </button>
                  <button
                    onClick={async () => {
                      try {
                        const r = await api.post(`/reports/from-scan/${scanResult.id}`);
                        window.location.assign('/app/reports');
                      } catch (err: any) {
                        alert('Report generation failed.');
                      }
                    }}
                    className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-sm transition-colors"
                  >
                    <FileText className="w-3.5 h-3.5 mr-1.5" />
                    Generate Formal Report
                  </button>
                </div>
              </div>

              {scanResult.summary && (
                <div className="text-xs text-slate-700 bg-slate-50 p-3 rounded-lg border border-slate-200 leading-relaxed">
                  <strong>Assessment Summary:</strong> {scanResult.summary}
                </div>
              )}
            </div>

            {/* Findings List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Confirmed Security Findings ({scanResult.findings?.length || 0})
                </h3>
                <span className="text-[11px] text-slate-500">Click finding to inspect evidence and remediation</span>
              </div>

              {scanResult.findings?.map((f: SecurityFinding, idx: number) => {
                const isExpanded = expandedFinding === f.id;
                return (
                  <div
                    key={f.id || idx}
                    className="bg-white rounded-xl border border-slate-200/90 shadow-sm overflow-hidden transition-all"
                  >
                    <div
                      onClick={() => setExpandedFinding(isExpanded ? null : f.id)}
                      className="p-4 hover:bg-slate-50/70 cursor-pointer flex items-center justify-between select-none"
                    >
                      <div className="flex items-center space-x-3 min-w-0 pr-4">
                        <SeverityBadge severity={f.severity} />
                        <span className="text-xs font-semibold text-slate-900 truncate">{f.title}</span>
                        {f.cwe_id && (
                          <span className="text-[10px] text-slate-400 font-mono bg-slate-100 px-1.5 py-0.5 rounded">
                            {f.cwe_id}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center space-x-3 shrink-0">
                        <span className="text-[11px] text-slate-400 hidden sm:inline">
                          {f.affected_component}
                        </span>
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-slate-400" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-slate-400" />
                        )}
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="p-5 border-t border-slate-100 bg-slate-50/50 space-y-3 text-xs">
                        <div>
                          <strong className="text-slate-900 block mb-0.5">Description:</strong>
                          <p className="text-slate-600 leading-relaxed">{f.description}</p>
                        </div>

                        {f.evidence && (
                          <div>
                            <strong className="text-slate-900 block mb-0.5">Verified Evidence:</strong>
                            <pre className="p-3 bg-white border border-slate-200 rounded-lg font-mono text-[11px] text-slate-800 overflow-x-auto whitespace-pre-wrap">
                              {f.evidence}
                            </pre>
                          </div>
                        )}

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                          <div className="p-3 bg-rose-50/60 border border-rose-100 rounded-lg">
                            <strong className="text-rose-900 block mb-0.5">Potential Business Impact:</strong>
                            <p className="text-rose-800 text-[11px] leading-relaxed">
                              {f.business_impact || 'Security posture degradation.'}
                            </p>
                          </div>
                          <div className="p-3 bg-emerald-50/60 border border-emerald-100 rounded-lg">
                            <strong className="text-emerald-900 block mb-0.5">Recommended Remediation:</strong>
                            <p className="text-emerald-800 text-[11px] leading-relaxed">
                              {f.remediation || 'Refer to OWASP Secure Headers guidelines.'}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 4 Assessment Pillars Grid (Explainer) */}
        {!scanResult && !isScanning && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
              <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center">
                <Layers className="w-4 h-4 stroke-[1.8]" />
              </div>
              <h3 className="text-xs font-semibold text-slate-900">HTTP Security Headers</h3>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Evaluates CSP, HSTS, X-Frame-Options, X-Content-Type-Options, and Referrer-Policy against OWASP Secure Headers standards.
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
              <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                <Cookie className="w-4 h-4 stroke-[1.8]" />
              </div>
              <h3 className="text-xs font-semibold text-slate-900">Cookie Security Audit</h3>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Inspects session tokens for Secure, HttpOnly, and SameSite enforcement to prevent session hijacking and cross-site leaks.
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <Lock className="w-4 h-4 stroke-[1.8]" />
              </div>
              <h3 className="text-xs font-semibold text-slate-900">TLS Transport Security</h3>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Tests SSL/TLS handshakes, certificate chains, and cipher suites. Never guesses TLS security on plaintext HTTP connections.
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
              <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
                <Terminal className="w-4 h-4 stroke-[1.8]" />
              </div>
              <h3 className="text-xs font-semibold text-slate-900">OWASP ZAP & Probes</h3>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Communicates with OWASP ZAP API daemon when available, and executes native web baseline vulnerability probes.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Manual Browser Storage Evidence Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-lg w-full p-6 shadow-xl border border-slate-200 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900">Log Browser Storage & Token Observation</h3>
                <p className="text-xs text-slate-500">Record manual observations from browser Developer Tools (Application tab).</p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleAddManualEvidence} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Observation Title</label>
                <input
                  type="text"
                  required
                  value={manualTitle}
                  onChange={(e) => setManualTitle(e.target.value)}
                  placeholder="e.g. JWT Auth Token Stored in Insecure localStorage"
                  className="w-full border border-slate-300 rounded-lg p-2"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Storage Medium</label>
                  <select
                    value={manualStorageType}
                    onChange={(e) => setManualStorageType(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 bg-white"
                  >
                    <option value="localStorage">localStorage</option>
                    <option value="sessionStorage">sessionStorage</option>
                    <option value="IndexedDB">IndexedDB</option>
                    <option value="Cookie (DevTools)">Cookie (DevTools)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Assessed Severity</label>
                  <select
                    value={manualSeverity}
                    onChange={(e) => setManualSeverity(e.target.value as FindingSeverity)}
                    className="w-full border border-slate-300 rounded-lg p-2 bg-white"
                  >
                    <option value="HIGH">HIGH (Authentication Token)</option>
                    <option value="MEDIUM">MEDIUM (User PII / Session Data)</option>
                    <option value="LOW">LOW (Non-sensitive Preference)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description</label>
                <textarea
                  required
                  rows={2}
                  value={manualDescription}
                  onChange={(e) => setManualDescription(e.target.value)}
                  placeholder="Describe how the token or credential was stored and accessed..."
                  className="w-full border border-slate-300 rounded-lg p-2"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Evidence / Value Sample</label>
                <textarea
                  required
                  rows={2}
                  value={manualEvidence}
                  onChange={(e) => setManualEvidence(e.target.value)}
                  placeholder="Key name, sample sanitized value (e.g. token=eyJhbGciOi...)"
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Remediation</label>
                <input
                  type="text"
                  value={manualRemediation}
                  onChange={(e) => setManualRemediation(e.target.value)}
                  placeholder="e.g. Store session tokens in HttpOnly, Secure cookies rather than web storage."
                  className="w-full border border-slate-300 rounded-lg p-2"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingManual}
                  className="px-4 py-1.5 font-semibold text-white bg-brand-600 hover:bg-brand-700 rounded-lg shadow-sm"
                >
                  {submittingManual ? 'Saving...' : 'Attach Finding'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
