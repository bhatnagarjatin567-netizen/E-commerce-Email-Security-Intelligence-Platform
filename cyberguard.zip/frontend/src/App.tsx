import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Sidebar } from './components/Sidebar';

// Public pages
import { HomePage } from './pages/public/HomePage';
import { LoginPage } from './pages/public/LoginPage';
import { RegisterPage } from './pages/public/RegisterPage';
import { PendingApprovalPage } from './pages/public/PendingApprovalPage';
import { AccessDeniedPage } from './pages/public/AccessDeniedPage';

// Dashboard pages
import { DashboardHome } from './pages/dashboard/DashboardHome';
import { AdminDashboardPage } from './pages/dashboard/AdminDashboardPage';
import { ScanHistoryPage } from './pages/dashboard/ScanHistoryPage';
import { ReportsPage } from './pages/dashboard/ReportsPage';
import { EcommerceScanPage } from './pages/dashboard/EcommerceScanPage';
import { EmailScanPage } from './pages/dashboard/EmailScanPage';
import { SmtpLabPage } from './pages/dashboard/SmtpLabPage';
import { UserSettingsPage } from './pages/dashboard/UserSettingsPage';

const ProtectedLayout: React.FC = () => {
  const { isAuthenticated, isLoading, user } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center space-y-2">
          <div className="w-8 h-8 border-2 border-brand-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-xs text-slate-500 font-medium">Validating security authorization...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    if (user && user.status === 'PENDING_APPROVAL') {
      return <Navigate to="/pending-approval" replace />;
    }
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="flex min-h-screen bg-slate-50 antialiased font-sans">
      <Sidebar />
      <Outlet />
    </div>
  );
};

const AdminRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAdmin, isLoading } = useAuth();

  if (isLoading) return null;
  if (!isAdmin) {
    return <Navigate to="/access-denied" replace />;
  }

  return <>{children}</>;
};

export const App: React.FC = () => {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public Website Routes */}
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/pending-approval" element={<PendingApprovalPage />} />
          <Route path="/access-denied" element={<AccessDeniedPage />} />

          {/* Internal Dashboard Routes */}
          <Route path="/app" element={<ProtectedLayout />}>
            <Route index element={<DashboardHome />} />
            <Route path="ecommerce" element={<EcommerceScanPage />} />
            <Route path="email" element={<EmailScanPage />} />
            <Route path="smtp-lab" element={<SmtpLabPage />} />
            <Route path="reports" element={<ReportsPage />} />
            <Route path="scans" element={<ScanHistoryPage />} />
            <Route path="settings" element={<UserSettingsPage />} />
            <Route
              path="admin"
              element={
                <AdminRoute>
                  <AdminDashboardPage />
                </AdminRoute>
              }
            />
          </Route>

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
};

export default App;
